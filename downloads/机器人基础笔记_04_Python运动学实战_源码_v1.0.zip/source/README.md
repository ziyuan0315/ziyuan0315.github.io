# 机器人基础：Python 运动学实战源码

本源码包配合《机器人基础（四）：用 Python 实现坐标变换、FK、IK 与 Jacobian》使用。

## 环境建议

- Python 3.11
- NumPy 1.x（`numpy<2`）
- SpatialMath
- Robotics Toolbox for Python

建议在独立虚拟环境中安装：

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux / macOS:
source .venv/bin/activate

python -m pip install --upgrade pip
pip install -r requirements.txt
python 00_check_env.py
```

也可以使用 `environment.yml` 创建 Conda 环境。

## 运行顺序

```bash
python 00_check_env.py
python 01_se3_basic.py
python 02_transform_chain_camera_to_base.py
python 03_two_link_fk.py
python 04_two_link_fk_visualize.py --q1 30 --q2 60 --l1 1.5 --l2 0.8
python 05_two_link_ik.py
python 06_two_link_jacobian.py
python 07_two_link_singularity.py
python 08_franka_panda_fk.py
python 09_franka_panda_ik.py
python 10_franka_panda_jacobian.py
python 11_batch_cases.py
```

## 文件说明

| 文件 | 内容 |
|---|---|
| `01_se3_basic.py` | RPY、旋转矩阵、齐次变换、SE3 |
| `02_transform_chain_camera_to_base.py` | 相机坐标系到机器人基座坐标系的变换链 |
| `03_two_link_fk.py` | 二连杆几何正运动学 |
| `04_two_link_fk_visualize.py` | 命令行参数化的 ASCII 构型展示 |
| `05_two_link_ik.py` | 二连杆解析 IK、数值容差、多解和边界 |
| `06_two_link_jacobian.py` | 解析 Jacobian、中心差分校验、微小位移求解 |
| `07_two_link_singularity.py` | 行列式、条件数、奇异值和秩 |
| `08_franka_panda_fk.py` | Panda 模型 FK 与关节限位检查 |
| `09_franka_panda_ik.py` | Panda LM 数值 IK 与 FK 残差验证 |
| `10_franka_panda_jacobian.py` | Panda 6×7 Jacobian 与零空间投影 |
| `11_batch_cases.py` | CSV 案例批量验证 |

## 重要说明

1. 关节角均使用弧度作为程序内部单位；命令行的 `--q1`、`--q2` 使用角度。
2. 二连杆 IK 只考虑理想平面位置约束，不包含关节限位、碰撞或轨迹规划。
3. 等长二连杆的目标点位于基座原点时，存在无穷多组 IK 解。示例函数只返回一组代表解。
4. Panda 的全零关节向量可以用于数学 FK 演示，但并不满足真实 Panda 的全部关节限位。请检查 `robot.qlim`。
5. `ikine_LM` 的 `q0` 是数值迭代初始猜测，不是目标可达性检测。
6. `jacob0` 返回基座坐标系下的几何 Jacobian，速度排列为 `[vx, vy, vz, wx, wy, wz]`。
7. 数值 IK 成功不等于真实运动安全。实际部署仍需检查关节位置、速度、加速度、碰撞、工作空间和轨迹连续性。

## 修订记录

详见 `CHANGELOG.md`。
