"""实战 10：Franka Panda 的 6x7 几何 Jacobian 与零空间。

Robotics Toolbox 的 jacob0 返回基座坐标系表达的几何 Jacobian，
速度排列为 [vx, vy, vz, wx, wy, wz]，与 Modern Robotics 常见的
[wx, wy, wz, vx, vy, vz] 旋量排列不同。
"""
import numpy as np

try:
    import roboticstoolbox as rtb
except Exception as exc:
    raise SystemExit(
        "请先安装 roboticstoolbox-python，检查 requirements.txt。\n" + str(exc)
    )


def main():
    robot = rtb.models.Panda()
    q = np.array([0.0, -0.3, 0.0, -2.2, 0.0, 2.0, 0.8])

    J = robot.jacob0(q)
    print("Panda 关节数量 =", robot.n)
    print("jacob0(q) 形状 =", J.shape)
    print("行顺序 = [vx, vy, vz, wx, wy, wz]")
    print("列顺序 = [q1, q2, q3, q4, q5, q6, q7]")
    print("J =\n", J)

    rank = np.linalg.matrix_rank(J)
    singular_values = np.linalg.svd(J, compute_uv=False)
    print("\nrank(J) =", rank)
    print("奇异值 =", singular_values)

    # Moore-Penrose 伪逆与零空间投影矩阵。
    identity = np.eye(robot.n)
    J_pinv = np.linalg.pinv(J)
    N = identity - J_pinv @ J

    # z 是希望实现的任意次级关节运动方向。
    z = np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0])
    qdot_null = N @ z

    print("\n零空间投影 N = I - J+ J")
    print(N)
    print("\n示例零空间关节速度 qdot_null =", qdot_null)
    print("末端速度残差 ||J qdot_null|| =", np.linalg.norm(J @ qdot_null))
    print("\n说明：该结果是当前构型附近的一阶瞬时关系，不是完整轨迹规划。")


if __name__ == "__main__":
    main()
