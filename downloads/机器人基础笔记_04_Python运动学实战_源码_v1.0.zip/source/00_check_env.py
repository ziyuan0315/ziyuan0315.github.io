"""检查机器人 Python 实战所需的核心依赖。

推荐环境：Python 3.11、NumPy < 2、SpatialMath、Robotics Toolbox。
本脚本只检查环境，不会自动安装或修改依赖。
"""
import importlib
import sys


def main():
    print("Python:", sys.version.replace("\n", " "))
    print("推荐使用 Python 3.11，并在独立虚拟环境中安装项目依赖。")

    checks = [
        ("numpy", "numpy"),
        ("spatialmath", "spatialmath-python"),
        ("roboticstoolbox", "roboticstoolbox-python"),
    ]

    all_ok = True
    numpy_version = None

    for module_name, package_name in checks:
        try:
            module = importlib.import_module(module_name)
            version = getattr(module, "__version__", "unknown")
            print(f"[OK] {package_name}: {version}")
            if module_name == "numpy":
                numpy_version = version
        except Exception as exc:
            all_ok = False
            print(f"[MISSING/ERROR] {package_name}: {exc}")

    if numpy_version:
        try:
            major = int(numpy_version.split(".")[0])
            if major >= 2:
                print(
                    "[WARN] 当前 NumPy >= 2。若 Robotics Toolbox 的二进制扩展"
                    "出现 ABI 错误，请按 requirements.txt 重建环境。"
                )
        except ValueError:
            print("[WARN] 无法解析 NumPy 版本，请手动检查依赖兼容性。")

    print(
        "\n环境检查通过。"
        if all_ok
        else "\n环境检查未通过，请先安装 requirements.txt 中的依赖。"
    )


if __name__ == "__main__":
    main()
