"""实战 8：Franka Panda 正运动学。

注意：机器人模型可以计算某个数学构型的 FK，不代表该构型满足硬件关节限位。
Panda 的全零关节向量仅作为数学参考；关节 4 的真实允许范围不包含 0。
"""
import numpy as np

try:
    import roboticstoolbox as rtb
except Exception as exc:
    raise SystemExit(
        "请先安装 roboticstoolbox-python，检查 requirements.txt。\n" + str(exc)
    )

np.set_printoptions(precision=4, suppress=True)


def within_joint_limits(robot, q):
    """根据模型关节限位判断 q 是否在范围内。"""
    limits = np.asarray(robot.qlim, dtype=float)
    q = np.asarray(q, dtype=float)
    return bool(np.all(q >= limits[0]) and np.all(q <= limits[1]))


def print_fk(robot, q, title, check_limits=True):
    T = robot.fkine(q)

    print("\n" + "=" * 72)
    print(title)
    print("q (rad) =", q)
    print("q (deg) =", np.rad2deg(q))
    if check_limits:
        print("是否满足模型关节限位 =", within_joint_limits(robot, q))

    print("\n末端位姿 ^B T_EE =")
    print(T)
    print("\n位置 xyz (m) =", T.t)
    print("旋转矩阵 R =\n", T.R)
    print("RPY xyz (rad) =", T.rpy(order="xyz"))
    print("RPY xyz (deg) =", np.rad2deg(T.rpy(order="xyz")))
    return T


def main():
    robot = rtb.models.Panda()
    print(robot)
    print("\nPanda 关节数量 robot.n =", robot.n)

    # 仅用于观察模型零位的数学 FK，不作为真实机器人可执行姿态。
    q_model_zero = np.zeros(robot.n)

    # 使用模型提供的 ready configuration，作为有效参考构型。
    q_ready = np.asarray(robot.qr, dtype=float).copy()

    q_goal = np.array([0.0, -0.4, 0.0, -2.2, 0.0, 2.0, np.pi / 4])

    print_fk(
        robot, q_model_zero,
        "模型零位：仅作数学 FK 参考，不代表可执行姿态",
    )
    print_fk(robot, q_ready, "Panda ready configuration")
    print_fk(robot, q_goal, "另一组关节目标构型")


if __name__ == "__main__":
    main()
