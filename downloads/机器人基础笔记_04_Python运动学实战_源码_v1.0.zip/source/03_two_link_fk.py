"""实战 3：手写平面二连杆正运动学（FK）。

q1：第一根连杆相对基座 x 轴的角度。
q2：第二根连杆相对第一根连杆的角度。
函数输入角度单位为弧度，连杆长度与坐标使用同一长度单位。
"""
import numpy as np


def fk(q1, q2, L1=1.0, L2=1.0):
    """输入两个关节角，返回末端在基座平面坐标系下的 [x, y]。"""
    x = L1 * np.cos(q1) + L2 * np.cos(q1 + q2)
    y = L1 * np.sin(q1) + L2 * np.sin(q1 + q2)
    return np.array([x, y], dtype=float)


if __name__ == "__main__":
    q1 = np.deg2rad(0.0)
    q2 = np.deg2rad(90.0)
    p = fk(q1, q2)
    print("q1=0°, q2=90°")
    print("末端位置 =", p)
    print("预期结果接近 [1, 1]")
