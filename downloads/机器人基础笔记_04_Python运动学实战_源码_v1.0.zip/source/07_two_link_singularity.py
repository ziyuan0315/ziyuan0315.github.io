"""实战 7：用行列式、条件数、奇异值观察二连杆奇异位形。

二连杆位置 Jacobian 的行列式：
    det(J) = L1 * L2 * sin(q2)

q2=0 和 q2=pi 时两根连杆共线，Jacobian 降秩。
"""
import numpy as np


L1 = 1.0
L2 = 1.0


def jacobian(q1, q2, L1=L1, L2=L2):
    return np.array([
        [-L1 * np.sin(q1) - L2 * np.sin(q1 + q2), -L2 * np.sin(q1 + q2)],
        [L1 * np.cos(q1) + L2 * np.cos(q1 + q2), L2 * np.cos(q1 + q2)],
    ], dtype=float)


def fk_tool(q1, q2, L1=L1, L2=L2):
    return np.array([
        L1 * np.cos(q1) + L2 * np.cos(q1 + q2),
        L1 * np.sin(q1) + L2 * np.sin(q1 + q2),
    ], dtype=float)


def main():
    cases = [
        (0, 90, "普通姿态"),
        (0, 30, "接近伸直"),
        (0, 10, "更接近伸直"),
        (0, 1, "非常接近伸直"),
        (0, 0, "完全伸直"),
        (0, 180, "完全折叠"),
    ]

    header = (
        f"{'姿态':<14} {'q2':>7} {'tool(x,y)':>23} "
        f"{'det(J)':>12} {'sigma_min':>12} {'cond(J)':>12} {'rank':>6}"
    )
    print("二连杆奇异位形数值观察")
    print("det(J) = L1 * L2 * sin(q2)")
    print(header)
    print("-" * len(header))

    for q1_deg, q2_deg, name in cases:
        q1, q2 = np.deg2rad([q1_deg, q2_deg])
        J = jacobian(q1, q2)
        tool = fk_tool(q1, q2)
        singular_values = np.linalg.svd(J, compute_uv=False)
        sigma_min = singular_values[-1]
        condition = np.linalg.cond(J)
        rank = np.linalg.matrix_rank(J)

        cond_text = "inf/极大" if not np.isfinite(condition) or condition > 1e12 else f"{condition:.3f}"
        tool_text = f"[{tool[0]: .4f}, {tool[1]: .4f}]"

        print(
            f"{name:<14} {q2_deg:>6.0f}° {tool_text:>23} "
            f"{np.linalg.det(J):>12.6f} {sigma_min:>12.4e} "
            f"{cond_text:>12} {rank:>6}"
        )

    print("\n解释：")
    print("1. q2 接近 0° 或 180° 时，两根连杆趋于共线。")
    print("2. 最小奇异值趋近 0，Jacobian 的条件数变大。")
    print("3. 奇异位形处，末端失去某个方向的一阶瞬时运动能力。")
    print("4. 条件数大时，直接求逆可能放大关节速度或数值误差。")


if __name__ == "__main__":
    main()
