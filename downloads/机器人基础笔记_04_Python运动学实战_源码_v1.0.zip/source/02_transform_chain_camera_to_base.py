"""实战 2：将相机坐标系中的目标位置转换到机器人基座坐标系。

示例数值仅用于演示变换链。真实系统中的相机外参应来自标定结果，
相机坐标轴的物理含义则取决于采用的相机坐标约定。
"""
import numpy as np
from spatialmath import SE3

np.set_printoptions(precision=6, suppress=True)


def main():
    # 相机坐标系 {C} 相对于基座坐标系 {B} 的位姿。
    # 平移分量以 {B} 表达；相机绕基座 z 轴旋转 30°。
    T_base_camera = (
        SE3.Trans(0.30, 0.00, 0.60)
        * SE3.Rz(np.deg2rad(30.0))
    )

    # 杯子坐标系 {cup} 相对于相机坐标系 {C} 的位姿。
    # 这里仅给出平移，等价于假设杯子坐标轴与相机坐标轴平行。
    T_camera_cup = SE3.Trans(0.50, -0.10, 0.20)

    # 中间坐标系 {C} 首尾衔接，得到杯子相对于基座的位姿。
    T_base_cup = T_base_camera * T_camera_cup

    print("^B T_C =")
    print(T_base_camera.A)
    print("\n^C T_cup =")
    print(T_camera_cup.A)
    print("\n^B T_cup = ^B T_C * ^C T_cup")
    print(T_base_cup.A)
    print("\n杯子在基座坐标系下的位置 xyz =", T_base_cup.t)

    # 如果任务只需要转换一个点，也可以直接使用齐次点。
    p_camera_h = np.array([0.50, -0.10, 0.20, 1.0])
    p_base_h = T_base_camera.A @ p_camera_h
    print("\n直接变换点坐标，p_base =", p_base_h[:3])


if __name__ == "__main__":
    main()
