"""实战 4：二连杆 FK 的终端几何展示。

通过命令行传入关节角和连杆长度：
    python 04_two_link_fk_visualize.py --q1 30 --q2 60 --l1 1.5 --l2 0.8

本脚本使用 ASCII 网格，不依赖图形窗口。
"""
import argparse
import numpy as np


def joint_positions(q1, q2, L1=1.0, L2=1.0):
    """返回基座、肘部和末端三个点的二维坐标。"""
    base = np.array([0.0, 0.0])
    elbow = np.array([L1 * np.cos(q1), L1 * np.sin(q1)])
    tool = elbow + np.array([
        L2 * np.cos(q1 + q2),
        L2 * np.sin(q1 + q2),
    ])
    return base, elbow, tool


def draw_ascii(points, size=25, lim=2.1):
    """将二维机械臂投影到终端字符网格。"""
    grid = [[" " for _ in range(size)] for _ in range(size)]

    def to_grid(x, y):
        col = int(round((x + lim) / (2 * lim) * (size - 1)))
        row = int(round((lim - y) / (2 * lim) * (size - 1)))
        return (
            max(0, min(size - 1, row)),
            max(0, min(size - 1, col)),
        )

    base, elbow, tool = points

    # 对每段连杆做线性采样，使终端网格中的连杆连续一些。
    for start, end in ((base, elbow), (elbow, tool)):
        for s in np.linspace(0.0, 1.0, max(18, size)):
            point = (1.0 - s) * start + s * end
            row, col = to_grid(point[0], point[1])
            grid[row][col] = "*"

    # 最后绘制关节点，避免被连杆采样字符覆盖。
    for label, point in (("B", base), ("E", elbow), ("T", tool)):
        row, col = to_grid(point[0], point[1])
        grid[row][col] = label

    print("\nASCII 示意图：B=base，E=elbow，T=tool，*=连杆")
    print("+" + "-" * size + "+")
    for row in grid:
        print("|" + "".join(row) + "|")
    print("+" + "-" * size + "+")


def main():
    parser = argparse.ArgumentParser(description="平面二连杆 FK 终端展示")
    parser.add_argument("--q1", type=float, default=45.0, help="关节 1 角度，单位 degree")
    parser.add_argument("--q2", type=float, default=45.0, help="关节 2 相对角度，单位 degree")
    parser.add_argument("--l1", type=float, default=1.0, help="第一根连杆长度")
    parser.add_argument("--l2", type=float, default=1.0, help="第二根连杆长度")
    parser.add_argument("--size", type=int, default=25, help="ASCII 网格边长")
    parser.add_argument("--lim", type=float, default=None, help="绘图坐标半宽；默认按最大臂展自动设置")
    args = parser.parse_args()

    if args.l1 <= 0 or args.l2 <= 0:
        parser.error("--l1 和 --l2 必须大于 0")
    if args.size < 9:
        parser.error("--size 建议不小于 9")

    q1, q2 = np.deg2rad([args.q1, args.q2])
    base, elbow, tool = joint_positions(q1, q2, args.l1, args.l2)

    # 自动留出 10% 边距，避免改变连杆长度后末端被默认绘图范围裁掉。
    lim = args.lim if args.lim is not None else 1.1 * (args.l1 + args.l2)
    if lim <= 0:
        parser.error("--lim 必须大于 0")

    print(
        f"输入：q1={args.q1:.1f}°, q2={args.q2:.1f}°, "
        f"L1={args.l1:.3f}, L2={args.l2:.3f}"
    )
    print("\nFK 计算结果：")
    print("base  =", np.round(base, 4))
    print("elbow =", np.round(elbow, 4))
    print("tool  =", np.round(tool, 4))
    print("\n第二根连杆相对基座的绝对方向角为 q1 + q2。")
    draw_ascii((base, elbow, tool), size=args.size, lim=lim)


if __name__ == "__main__":
    main()
