"""实战 5：平面二连杆解析 IK，多解、边界与无解处理。

这是理想几何模型，不包含真实机械臂的关节限位、碰撞和路径约束。
目标点仅描述末端位置，不约束末端工具朝向。
"""
import numpy as np
from math import atan2, pi


def fk(q1, q2, L1=1.0, L2=1.0):
    """二连杆正运动学，用于验证 IK 解。"""
    return np.array([
        L1 * np.cos(q1) + L2 * np.cos(q1 + q2),
        L1 * np.sin(q1) + L2 * np.sin(q1 + q2),
    ], dtype=float)


def wrap_to_pi(angle):
    """将角度规范到 [-pi, pi)。"""
    return (angle + pi) % (2.0 * pi) - pi


def ik(
    x, y, L1=1.0, L2=1.0,
    cos_tol=1e-10,
    angle_tol=1e-9,
):
    """返回所有不同的解析 IK 解，每组解为 (q1, q2)，单位 rad。

    cos_tol 用于处理浮点计算造成的微小越界；
    angle_tol 用于按角度周期性判断两个解是否重复。
    """
    values = np.asarray([x, y, L1, L2], dtype=float)
    if not np.all(np.isfinite(values)):
        raise ValueError("x、y、L1、L2 必须是有限数值")
    if L1 <= 0.0 or L2 <= 0.0:
        raise ValueError("连杆长度 L1、L2 必须大于 0")
    if cos_tol < 0.0 or angle_tol < 0.0:
        raise ValueError("容差不能为负数")

    r2 = x * x + y * y
    cos_q2_raw = (r2 - L1 * L1 - L2 * L2) / (2.0 * L1 * L2)

    # 超出容差范围才判定为几何无解。
    if cos_q2_raw < -1.0 - cos_tol or cos_q2_raw > 1.0 + cos_tol:
        return []

    # 将舍入误差造成的微小越界修正到反余弦定义域。
    cos_q2 = float(np.clip(cos_q2_raw, -1.0, 1.0))

    # 等长连杆、目标在基座原点：q2=pi，但 q1 任意，实际有无穷多解。
    # 函数返回一组代表解，不意味着该解是唯一解。
    scale = max(1.0, L1, L2)
    if np.hypot(x, y) <= 1e-12 * scale and abs(L1 - L2) <= 1e-12 * scale:
        return [(0.0, pi)]

    sin_abs = float(np.sqrt(max(0.0, 1.0 - cos_q2 * cos_q2)))

    # 使用 atan2(sin, cos) 同时保留正、负两个肘部构型分支。
    q2_candidates = [
        atan2(sin_abs, cos_q2),
        atan2(-sin_abs, cos_q2),
    ]

    solutions = []
    for q2 in q2_candidates:
        q1 = atan2(y, x) - atan2(
            L2 * np.sin(q2),
            L1 + L2 * np.cos(q2),
        )

        q1 = wrap_to_pi(q1)
        q2 = wrap_to_pi(q2)

        # q2=0 或 q2=pi 时，正负分支可能是同一个物理构型。
        duplicate = any(
            abs(wrap_to_pi(q1 - old_q1)) < angle_tol
            and abs(wrap_to_pi(q2 - old_q2)) < angle_tol
            for old_q1, old_q2 in solutions
        )

        if not duplicate:
            solutions.append((q1, q2))

    return solutions


def print_case(target, L1=1.0, L2=1.0):
    x, y = target
    solutions = ik(x, y, L1, L2)
    print(f"\n目标点={target}, L1={L1}, L2={L2}")
    if not solutions:
        print("无解：目标超出几何工作空间。")
        return

    print(f"返回 {len(solutions)} 组代表解：")
    for index, (q1, q2) in enumerate(solutions, 1):
        reached = fk(q1, q2, L1, L2)
        error = np.linalg.norm(reached - np.array([x, y]))
        print(
            f"解 {index}: q1={np.rad2deg(q1):.4f}°, "
            f"q2={np.rad2deg(q2):.4f}°"
        )
        print("  FK 验证 =", np.round(reached, 8))
        print(f"  位置残差 = {error:.3e}")


if __name__ == "__main__":
    print_case((1.0, 1.0))
    print_case((2.0, 0.0))       # 外边界：两分支合并
    print_case((3.0, 0.0))       # 外部不可达
    print_case((0.0, 0.0))       # 等长连杆内边界：无穷多解，返回代表解
    print_case((0.7, 0.0), 1.5, 0.8)  # 不等长连杆内边界
