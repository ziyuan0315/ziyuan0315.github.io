"""实战 1：六元组位姿、旋转矩阵与 SE(3) 齐次变换。

本文件采用列向量约定：
    p_A = T_A_B @ p_B

RPY 组合约定：
    R = Rz(yaw) @ Ry(pitch) @ Rx(roll)

所有角度在函数内部均使用弧度。
"""
import numpy as np
from spatialmath import SE3

np.set_printoptions(precision=4, suppress=True)


def Rx(roll: float) -> np.ndarray:
    """绕 x 轴旋转 roll 弧度。"""
    c, s = np.cos(roll), np.sin(roll)
    return np.array([
        [1.0, 0.0, 0.0],
        [0.0, c, -s],
        [0.0, s, c],
    ])


def Ry(pitch: float) -> np.ndarray:
    """绕 y 轴旋转 pitch 弧度。"""
    c, s = np.cos(pitch), np.sin(pitch)
    return np.array([
        [c, 0.0, s],
        [0.0, 1.0, 0.0],
        [-s, 0.0, c],
    ])


def Rz(yaw: float) -> np.ndarray:
    """绕 z 轴旋转 yaw 弧度。"""
    c, s = np.cos(yaw), np.sin(yaw)
    return np.array([
        [c, -s, 0.0],
        [s, c, 0.0],
        [0.0, 0.0, 1.0],
    ])


def rpy_to_R(roll: float, pitch: float, yaw: float) -> np.ndarray:
    """按 Rz(yaw) @ Ry(pitch) @ Rx(roll) 组合 RPY。"""
    return Rz(yaw) @ Ry(pitch) @ Rx(roll)


def pose6_to_T(
    x: float, y: float, z: float,
    roll: float, pitch: float, yaw: float
) -> np.ndarray:
    """将 [x, y, z, roll, pitch, yaw] 转换为 4x4 齐次矩阵。"""
    T = np.eye(4)
    T[:3, :3] = rpy_to_R(roll, pitch, yaw)
    T[:3, 3] = np.array([x, y, z], dtype=float)
    return T


def main():
    x, y, z = 0.4, 0.2, 0.3
    roll, pitch, yaw = np.deg2rad([0.0, 0.0, 90.0])

    T_base_tool = pose6_to_T(x, y, z, roll, pitch, yaw)
    print("T_base_tool =")
    print(T_base_tool)

    # 工具坐标系下的点，最后一个分量为 1，表示齐次点。
    p_tool = np.array([0.1, 0.0, 0.0, 1.0])
    p_base = T_base_tool @ p_tool
    print("\np_tool =", p_tool[:3])
    print("p_base =", p_base[:3])

    # SpatialMath 的 SE3 将齐次变换封装为刚体位姿对象。
    T_se3 = SE3(T_base_tool)
    print("\nSE3 对象底层矩阵 T_se3.A =")
    print(T_se3.A)

    # 纯旋转示例：角度参数使用弧度。
    T_rot = SE3.Rz(np.deg2rad(90.0))
    print("\n绕 z 轴旋转 90°：")
    print(T_rot.A)

    # 先在原点处旋转，再平移到指定位置，得到 [R, t]。
    T_pos = SE3.Trans(0.4, 0.2, 0.3)
    T_pose = T_pos * T_rot
    print("\nT_pos * T_rot =")
    print(T_pose.A)


if __name__ == "__main__":
    main()
