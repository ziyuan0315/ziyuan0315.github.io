"""批量验证坐标变换、二连杆 FK/IK/Jacobian 与 Panda 模型案例。

批量脚本从主脚本导入 FK、IK、Jacobian 函数，避免维护第二份不同的 IK 实现。
"""
from pathlib import Path
import csv
import importlib.util
import numpy as np
from spatialmath import SE3
import roboticstoolbox as rtb

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)


def load_script_module(module_name, filename):
    """从同目录脚本加载函数；主脚本的 __main__ 部分不会执行。"""
    path = ROOT / filename
    spec = importlib.util.spec_from_file_location(module_name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read_rows(filename):
    with (DATA / filename).open("r", encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


fk_module = load_script_module("two_link_fk", "03_two_link_fk.py")
ik_module = load_script_module("two_link_ik", "05_two_link_ik.py")
jac_module = load_script_module("two_link_jacobian", "06_two_link_jacobian.py")


def main():
    lines = ["1) 坐标变换：camera frame -> base frame"]

    for row in read_rows("coordinate_cases.csv"):
        T_base_camera = (
            SE3.Trans(
                float(row["camera_x_base"]),
                float(row["camera_y_base"]),
                float(row["camera_z_base"]),
            )
            * SE3.Rz(np.deg2rad(float(row["camera_yaw_deg"])))
        )
        p_camera_h = np.array([
            float(row["cup_x_camera"]),
            float(row["cup_y_camera"]),
            float(row["cup_z_camera"]),
            1.0,
        ])
        p_base = (T_base_camera.A @ p_camera_h)[:3]
        lines.append(f"- {row['case_id']}: cup_base={np.round(p_base, 4)}")

    lines.append("\n2) 二连杆 FK / IK / Jacobian")
    for row in read_rows("two_link_cases.csv"):
        L1, L2 = float(row["L1"]), float(row["L2"])

        if row["q1_deg"] and row["q2_deg"]:
            q1, q2 = np.deg2rad([float(row["q1_deg"]), float(row["q2_deg"])])
            point = fk_module.fk(q1, q2, L1, L2)
            det_j = np.linalg.det(jac_module.jacobian(q1, q2, L1, L2))
            lines.append(
                f"- {row['case_id']}: FK={np.round(point, 4)}, detJ={det_j:.6f}"
            )
        elif row["target_x"] and row["target_y"]:
            target_x = float(row["target_x"])
            target_y = float(row["target_y"])
            solutions = ik_module.ik(target_x, target_y, L1, L2)
            if not solutions:
                lines.append(f"- {row['case_id']}: IK 无解")
            else:
                text = "; ".join(
                    f"({np.rad2deg(a):.2f}°, {np.rad2deg(b):.2f}°)"
                    for a, b in solutions
                )
                lines.append(f"- {row['case_id']}: IK 解={text}")

    lines.append("\n3) Franka Panda FK")
    robot = rtb.models.Panda()
    for row in read_rows("panda_cases.csv"):
        q = np.array([float(row[f"q{i}"]) for i in range(1, 8)])
        T = robot.fkine(q)
        qlim = np.asarray(robot.qlim, dtype=float)
        limits_ok = np.all(q >= qlim[0]) and np.all(q <= qlim[1])
        lines.append(
            f"- {row['case_id']}: xyz={np.round(T.t, 4)}, "
            f"joint_limits={bool(limits_ok)}"
        )

    text = "\n".join(lines)
    print(text)
    output_path = OUT / "batch_validation_result.txt"
    output_path.write_text(text + "\n", encoding="utf-8")
    print(f"\n结果已写入：{output_path}")


if __name__ == "__main__":
    main()
