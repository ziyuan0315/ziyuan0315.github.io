"""实战 9：Franka Panda 数值逆运动学。

q_target：用于生成目标末端位姿的已知关节构型。
q_seed：数值 IK 迭代的初始猜测。它不是目标可达性检测。
"""
import numpy as np

try:
    import roboticstoolbox as rtb
except Exception as exc:
    raise SystemExit(
        "请先安装 roboticstoolbox-python，检查 requirements.txt。\n" + str(exc)
    )


def rotation_error_angle(R_target, R_actual):
    """由相对旋转矩阵计算姿态误差角，返回 rad。"""
    R_error = R_target.T @ R_actual
    cos_angle = (np.trace(R_error) - 1.0) / 2.0
    cos_angle = np.clip(cos_angle, -1.0, 1.0)
    return float(np.arccos(cos_angle))


def main():
    robot = rtb.models.Panda()

    # 用一组位于关节范围内的关节角生成一个确定可达的目标位姿。
    q_target = np.array([0.0, -0.3, 0.0, -2.2, 0.0, 2.0, 0.8])
    T_target = robot.fkine(q_target)

    # 使用模型提供的 ready configuration 作为数值迭代初值。
    q_seed = np.asarray(robot.qr, dtype=float).copy()

    print("目标关节构型 q_target =", q_target)
    print("IK 初始猜测 q_seed =", q_seed)
    print("\n目标位姿 T_target =")
    print(T_target)

    # joint_limits=True 明确要求求解结果满足机器人模型中的关节限位。
    solution = robot.ikine_LM(
        T_target,
        q0=q_seed,
        joint_limits=True,
    )

    print("\nIK 是否成功 =", solution.success)
    print("求解结果 q =", solution.q)
    print("迭代次数 =", getattr(solution, "iterations", "当前版本未提供"))
    print("残差 =", getattr(solution, "residual", "当前版本未提供"))
    print("求解原因 =", getattr(solution, "reason", "当前版本未提供"))

    if not solution.success:
        print("求解器未报告成功；不要将该结果直接用于执行。")
        return

    q_solution = np.asarray(solution.q, dtype=float)
    T_check = robot.fkine(q_solution)

    position_error = np.linalg.norm(T_check.t - T_target.t)
    orientation_error = rotation_error_angle(T_target.R, T_check.R)
    qlim = np.asarray(robot.qlim, dtype=float)
    limits_ok = bool(
        np.all(q_solution >= qlim[0]) and np.all(q_solution <= qlim[1])
    )

    print("\nFK 验证位姿 =")
    print(T_check)
    print(f"位置误差 = {position_error:.3e} m")
    print(f"姿态误差 = {orientation_error:.3e} rad")
    print("是否满足模型关节限位 =", limits_ok)


if __name__ == "__main__":
    main()
