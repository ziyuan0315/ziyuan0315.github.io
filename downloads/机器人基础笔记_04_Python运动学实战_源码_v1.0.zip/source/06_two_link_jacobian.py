"""实战 6：二连杆解析 Jacobian 与末端微小位移求解。"""
import numpy as np


def fk(q1, q2, L1=1.0, L2=1.0):
    """返回末端二维位置。"""
    return np.array([
        L1 * np.cos(q1) + L2 * np.cos(q1 + q2),
        L1 * np.sin(q1) + L2 * np.sin(q1 + q2),
    ], dtype=float)


def jacobian(q1, q2, L1=1.0, L2=1.0):
    """位置 Jacobian：delta_p ≈ J @ delta_q。"""
    return np.array([
        [
            -L1 * np.sin(q1) - L2 * np.sin(q1 + q2),
            -L2 * np.sin(q1 + q2),
        ],
        [
            L1 * np.cos(q1) + L2 * np.cos(q1 + q2),
            L2 * np.cos(q1 + q2),
        ],
    ], dtype=float)


def numerical_jacobian(q1, q2, L1=1.0, L2=1.0, eps=1e-6):
    """用中心差分近似 Jacobian，作为解析结果的数值校验。"""
    col1 = (
        fk(q1 + eps, q2, L1, L2) - fk(q1 - eps, q2, L1, L2)
    ) / (2.0 * eps)
    col2 = (
        fk(q1, q2 + eps, L1, L2) - fk(q1, q2 - eps, L1, L2)
    ) / (2.0 * eps)
    return np.column_stack((col1, col2))


def solve_joint_increment(q1, q2, delta_p, L1=1.0, L2=1.0, cond_limit=1e10):
    """在非奇异、条件数可接受时求解 J delta_q = delta_p。"""
    J = jacobian(q1, q2, L1, L2)
    condition = np.linalg.cond(J)

    if not np.isfinite(condition) or condition > cond_limit:
        raise np.linalg.LinAlgError(
            f"Jacobian 条件数过大（{condition:.3e}），不建议直接 solve；"
            "应考虑 DLS 或其他稳定求解方法。"
        )

    # solve(J, delta_p) 比显式计算 inv(J) @ delta_p 更合适。
    delta_q = np.linalg.solve(J, np.asarray(delta_p, dtype=float))
    return J, delta_q, condition


if __name__ == "__main__":
    q1, q2 = np.deg2rad([0.0, 90.0])
    delta_p = np.array([0.0, 0.1])

    J, delta_q, condition = solve_joint_increment(q1, q2, delta_p)
    J_fd = numerical_jacobian(q1, q2)

    print("当前关节角：q1=0°, q2=90°")
    print("J =\n", J)
    print("数值差分 J_fd =\n", J_fd)
    print("解析与数值 Jacobian 的差异范数 =", np.linalg.norm(J - J_fd))
    print("期望末端微小位移 delta_p =", delta_p)
    print("求得关节变化 delta_q(rad) =", delta_q)
    print("求得关节变化 delta_q(deg) =", np.rad2deg(delta_q))
    print("cond(J) =", condition)
