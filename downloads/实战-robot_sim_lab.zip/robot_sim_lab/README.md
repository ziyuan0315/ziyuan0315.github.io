# 机器人仿真实战｜三平台 Franka Panda 抓方块 + AGV 导航寻物（110 分钟版）

本项目服务于《搭建第一个机器人仿真环境》实战课，承接第二章 1–3 节中的三个概念主线：

```text
仿真环境：不是三维展示，而是可执行的机器人任务场景
通信与数据：模型文件、状态、控制输入、TF/日志让系统可调试
Sim2Real：明确仿真假设与真实约束之间的差距
```

本节把这些概念落到可运行代码中：**Swift、MuJoCo、Isaac Sim 三个平台，每个平台都包含 Franka 抓方块和 AGV 导航寻物两个任务**。

---

## 1. 代码命名逻辑

当前代码命名采用：

```text
平台顺序编号 + 平台名 + 任务名.py
```

| 编号 | 平台 | 文件 | 课堂作用 |
|---|---|---|---|
| 01 | Swift / Robotics Toolbox | `01_swift_panda_pick_cube.py` | Franka Panda 抓方块，讲 IK、q_target、P 控制器、tool0 |
| 02 | Swift / Robotics Toolbox | `02_swift_agv_navigation.py` | AGV 导航寻物，讲 map、A* path、sensor range、target_found |
| 03 | MuJoCo | `03_mujoco_panda_pick_cube.py` | Franka Panda 抓方块，讲 MJCF、qpos/qvel/ctrl、mj_step |
| 04 | MuJoCo | `04_mujoco_agv_navigation.py` | AGV 导航寻物，讲 MuJoCo 世界中的障碍、目标、底盘状态和日志 |
| 05 | Isaac Sim | `05_isaac_panda_pick_cube.py` | Franka PickPlaceController，讲 World、Franka、Action、world.step |
| 06 | Isaac Sim | `06_isaac_agv_navigation.py` | Jetbot/AGV，讲 DifferentialController、wheel actions、world.step |
| 07 | 通用教学小例子 | `07_agv_navigation_search.py` | 不绑定平台的 A* AGV GIF，用作导航概念补充 |

授课主线按平台推进：

```text
Swift：01 Franka + 02 AGV
MuJoCo：03 Franka + 04 AGV
Isaac Sim：05 Franka + 06 AGV
补充：07 通用 AGV A* 小例子
```

---

## 2. 云实验推荐入口：Streamlit 一页驱动

云实验支持端口转发时，建议统一运行 Streamlit 入口，而不是让学员分别手动运行每个 `.py`：

```bash
cd robot_sim_lab_panda_agv_110min
bash run_streamlit_cloud.sh
```

等价完整命令：

```bash
streamlit run streamlit_robot_sim_lab.py \
  --server.port=8501 \
  --server.address=0.0.0.0 \
  --server.headless=true \
  --server.enableCORS=false \
  --server.enableXsrfProtection=false
```

然后在云实验右侧端口管理里选择 `8501`，点击“查看预览”。不要直接访问终端打印的 External URL。

Streamlit 页面包含：

- Swift：Franka headless 验证、Swift AGV GIF/CSV、Swift 3D 端口说明；
- MuJoCo：Franka 抓方块 GIF/CSV、AGV 导航 GIF/CSV；
- Isaac Sim：Franka 与 AGV 脚本源码、运行命令、环境检查；
- 讲稿、练习、平台对比速查表。

> 注意：Swift 和 MuJoCo 示例可以由 Streamlit 页面按钮触发；Isaac Sim 示例必须在 Isaac Sim 环境中用 `${ISAACSIM_PATH}/python.sh` 单独运行。

---

## 3. 目录结构

```text
robot_sim_lab_panda_agv_110min/
├── 01_swift_panda_pick_cube.py       # Swift/RTB：Franka Panda 抓方块
├── 02_swift_agv_navigation.py        # Swift/RTB：AGV 导航寻物，GIF/CSV 或 Swift 3D
├── 03_mujoco_panda_pick_cube.py      # MuJoCo：Franka Panda 抓方块，GIF/CSV 或 viewer
├── 04_mujoco_agv_navigation.py       # MuJoCo：AGV 导航寻物，GIF/CSV
├── 05_isaac_panda_pick_cube.py       # Isaac Sim：Franka + PickPlaceController
├── 06_isaac_agv_navigation.py        # Isaac Sim：Jetbot/AGV + DifferentialController
├── 07_agv_navigation_search.py       # 通用 A* AGV 导航寻物小例子
├── streamlit_robot_sim_lab.py        # 云实验一页式入口
├── swift_compat.py                     # Swift/websockets 新版本兼容补丁
├── run_streamlit_cloud.sh            # 云实验启动脚本
├── assets/mujoco_menagerie/...       # 官方 Panda MJCF 模型，含 LICENSE
├── data/                             # 课堂参数表、栅格地图、生成的 MJCF
├── docs/                             # 学员端说明、技术背景、讲稿、练习题、平台对比
├── outputs/                          # GIF、CSV、预览图
├── screenshots/                      # 运行截图汇总
├── run_logs/                         # 运行日志与验证摘要
├── requirements.txt
└── environment.yml
```

三平台六段核心代码矩阵见：`docs/三平台完整代码矩阵.md`。

---

## 4. 环境安装

推荐 Python 3.10/3.11。Robotics Toolbox 在部分 Python/NumPy 组合下对二进制依赖敏感，课堂云实验建议固定环境。

```bash
cd robot_sim_lab_panda_agv_110min
python -m pip install -r requirements.txt
```

如果云环境使用 Python 3.11，建议确保：

```bash
python -m pip install "numpy<2" roboticstoolbox-python spatialmath-python spatialgeometry mujoco pillow streamlit
```

### 4.1 Swift 可视化兼容说明

如果运行 `python 01_swift_panda_pick_cube.py` 或 `python 02_swift_agv_navigation.py --swift` 出现：

```text
RuntimeError: no running event loop
```

这通常不是机器人代码逻辑错误，而是当前环境中的 `websockets` 版本较新，和 Robotics Toolbox 自带的 `swift` 可视化服务启动方式不兼容。本项目已加入 `swift_compat.py`，两个 Swift 脚本会自动应用兼容补丁。正常运行时可能看到：

```text
已应用 Swift/websockets 兼容补丁：当前环境 websockets 版本较新。
```

如果仍然报同类错误，再执行：

```bash
pip install "websockets<15"
```

优先建议使用本项目脚本中的补丁，不要直接修改 `site-packages` 里的 swift 源码。

---

## 5. 单独运行命令

### 5.1 Swift：Franka Panda 抓方块

无可视化验证：

```bash
python 01_swift_panda_pick_cube.py --headless
```

原生 Swift 3D：

```bash
python 01_swift_panda_pick_cube.py
```

云平台如支持端口映射，通常需要打开：

```text
52000 / 53000
```


> 视觉说明：`02_swift_agv_navigation.py --swift` 中，蓝色小车是 AGV，黑色小块是车载相机，绿色点圈是传感器探测范围，橙红球是目标物。旧版曾用半透明绿球表示探测范围，在部分浏览器里容易看成“AGV 是绿球”，最新版已改为地面绿点圈。

浏览器参考：

```text
http://localhost:52000/?53000
```

### 5.2 Swift：AGV 导航寻物

生成 GIF/CSV：

```bash
python 02_swift_agv_navigation.py --record
```

输出：

```text
outputs/swift_agv_navigation.gif
outputs/swift_agv_navigation_preview.png
outputs/swift_agv_navigation_log.csv
```

打开 Swift 原生 3D：

```bash
python 02_swift_agv_navigation.py --swift
```

### 5.3 MuJoCo：Franka Panda 抓方块

生成 GIF/CSV：

```bash
python 03_mujoco_panda_pick_cube.py --record
```

输出：

```text
outputs/mujoco_panda_pick_cube.gif
outputs/mujoco_panda_pick_log.csv
```

如需 native viewer：

```bash
python 03_mujoco_panda_pick_cube.py --viewer
```

### 5.4 MuJoCo：AGV 导航寻物

```bash
python 04_mujoco_agv_navigation.py --record
```

输出：

```text
outputs/mujoco_agv_navigation.gif
outputs/mujoco_agv_navigation_preview.png
outputs/mujoco_agv_navigation_log.csv
```

### 5.5 Isaac Sim：Franka Panda 抓方块

必须使用 Isaac Sim 自带 Python，不要用系统 Python：

```bash
${ISAACSIM_PATH}/python.sh 05_isaac_panda_pick_cube.py
```

主线：

```text
SimulationApp -> World -> Franka -> Cube -> PickPlaceController -> ArticulationAction -> world.step(render=True)
```

### 5.6 Isaac Sim：AGV / Jetbot 导航寻物

```bash
${ISAACSIM_PATH}/python.sh 06_isaac_agv_navigation.py
```

主线：

```text
A* waypoint -> [linear_speed, angular_speed] -> DifferentialController -> wheel_actions -> world.step(render=True)
```

### 5.7 通用 AGV A* 小例子

```bash
python 07_agv_navigation_search.py
```

输出：

```text
outputs/agv_search.gif
outputs/agv_search_preview.png
```

---

## 6. 110 分钟授课建议

| 时间 | 内容 | 关键问题 |
|---|---|---|
| 0–8 min | 统一任务和环境 | 为什么同一个任务要在三种平台里跑？ |
| 8–32 min | Swift：Franka + AGV | IK 如何把目标位姿变成 q_target？A* 如何让 AGV 找到目标附近？ |
| 32–62 min | MuJoCo：Franka + AGV | MJCF 如何描述模型？data.ctrl 和 qpos 为什么不是一回事？AGV 的路径和物理 step 如何结合？ |
| 62–92 min | Isaac Sim：Franka + AGV | World、Stage、Controller、Action 各负责什么？工业级仿真为什么更重？ |
| 92–105 min | 三平台对比 | 遇到新平台，按哪几个接口去判断？ |
| 105–110 min | 总结与作业 | 让学生能复述“模型—状态—控制—step—证据”。 |

---

## 7. 课堂提醒

- Swift Franka 是教学稳定版任务链，用于讲清楚 IK、q_target、P 控制器，不要声称它完成了真实接触物理。
- Swift AGV 是轻量导航逻辑示例，用于讲清 map、pose、A* path 和 target_found，不等同于真实 SLAM/Nav2。
- MuJoCo Panda 使用官方 Menagerie Panda 模型；为课堂稳定演示，脚本中对 cube 做了跟随处理。真实抓取还需要细调接触、摩擦、夹爪力和控制策略。
- MuJoCo AGV 是教学版平面导航，用于讲清楚路径规划如何进入仿真环境，不等同于完整底盘动力学控制。
- Isaac Sim API 会随版本变化，现场优先使用 Isaac 自带示例验证 Franka/PickPlaceController 或 WheeledRobot/DifferentialController，再运行课程脚本。

---

## 8. 参考来源

- Robotics Toolbox for Python / Swift / Panda：<https://github.com/petercorke/robotics-toolbox-python>
- MuJoCo Python API：<https://mujoco.readthedocs.io/en/stable/python.html>
- MuJoCo `mj_step` simulation：<https://mujoco.readthedocs.io/en/stable/programming/simulation.html>
- MuJoCo Menagerie Franka Panda：<https://github.com/google-deepmind/mujoco_menagerie/tree/main/franka_emika_panda>
- Isaac Sim Franka Pick and Place：<https://docs.isaacsim.omniverse.nvidia.com/6.0.0/examples/manipulation_franka_pick_place.html>
- Isaac Sim mobile robot controllers：<https://docs.isaacsim.omniverse.nvidia.com/6.0.0/robot_simulation/mobile_robot_controllers.html>


### 5.3.1 macOS 上运行 MuJoCo viewer 的特殊说明

如果在 Mac 上运行：

```bash
python 03_mujoco_panda_pick_cube.py --viewer
```

出现：

```text
RuntimeError: `launch_passive` requires that the Python script be run under `mjpython` on macOS
```

这是 MuJoCo viewer 在 macOS 上的限制，不是模型文件错误。正确方式是：

```bash
mjpython 03_mujoco_panda_pick_cube.py --viewer
mjpython 04_mujoco_agv_navigation.py --viewer
```

本项目已加入 `mujoco_viewer_compat.py`，在 Mac 上用普通 `python ... --viewer` 时会自动切换到 `mjpython`。如果自动切换失败，手动执行上面的 `mjpython` 命令即可。

---

### 5.4 Isaac Sim：运行方式说明

`05_isaac_panda_pick_cube.py` 和 `06_isaac_agv_navigation.py` 不能用普通 Python 直接运行。出现下面错误是正常的环境问题，不是脚本逻辑问题：

```text
ModuleNotFoundError: No module named 'isaacsim'
```

正确方式是在安装 Isaac Sim 的 NVIDIA GPU 机器/云实验中，用 Isaac Sim 自带 Python：

```bash
${ISAACSIM_PATH}/python.sh 05_isaac_panda_pick_cube.py
${ISAACSIM_PATH}/python.sh 06_isaac_agv_navigation.py
```

如果不知道 `ISAACSIM_PATH`，在 Linux/云服务器上尝试：

```bash
find ~/.local/share/ov/pkg /opt -name python.sh 2>/dev/null | grep -i isaac
```

Mac 本机 base 环境通常不能运行 Isaac Sim 3D 仿真；Mac 上可讲解源码和运行 Swift/MuJoCo，Isaac Sim 部分建议切到 GPU 云实验/服务器演示。

---
