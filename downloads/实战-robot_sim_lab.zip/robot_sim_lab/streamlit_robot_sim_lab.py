"""
云实验 Streamlit 驱动入口：三平台按“Franka 抓方块 + AGV 导航寻物”顺序讲。

推荐运行：
    cd robot_sim_lab_panda_agv_110min
    streamlit run streamlit_robot_sim_lab.py \
      --server.port=8501 \
      --server.address=0.0.0.0 \
      --server.headless=true \
      --server.enableCORS=false \
      --server.enableXsrfProtection=false

然后在云实验右侧端口管理中打开 8501。不要直接打开终端打印的 External URL。
"""
from __future__ import annotations

import base64
import csv
import os
import subprocess
import sys
from pathlib import Path

import streamlit as st

ROOT = Path(__file__).resolve().parent
OUTPUTS = ROOT / "outputs"
LOGS = ROOT / "run_logs"
DOCS = ROOT / "docs"

st.set_page_config(page_title="三平台 Panda + AGV 仿真实战", page_icon="🤖", layout="wide")

STYLE = """
<style>
.block-container { padding-top: 1.2rem; padding-bottom: 2rem; }
.small-note { color: #64748b; font-size: 0.92rem; }
.cmd-box { background: #0f172a; color: #e2e8f0; padding: 14px 16px; border-radius: 10px; font-family: Menlo, Consolas, monospace; white-space: pre-wrap; }
.good { color: #16a34a; font-weight: 700; }
.warn { color: #ea580c; font-weight: 700; }
hr { margin-top: 1.2rem; margin-bottom: 1.2rem; }
</style>
"""
st.markdown(STYLE, unsafe_allow_html=True)


def code_block(text: str):
    st.markdown(f"<div class='cmd-box'>{text}</div>", unsafe_allow_html=True)


def run_command(cmd: list[str], timeout: int = 120) -> tuple[int, str]:
    """运行课堂脚本，返回 returncode 和合并日志。"""
    env = os.environ.copy()
    env.setdefault("PYTHONUNBUFFERED", "1")
    try:
        p = subprocess.run(
            cmd,
            cwd=str(ROOT),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=timeout,
        )
        return p.returncode, p.stdout
    except subprocess.TimeoutExpired as e:
        out = e.stdout or ""
        return 124, out + f"\n[TIMEOUT] 命令超过 {timeout}s，已停止。"
    except Exception as e:
        return 1, f"[ERROR] {type(e).__name__}: {e}"


def save_log(name: str, text: str):
    LOGS.mkdir(exist_ok=True)
    (LOGS / name).write_text(text, encoding="utf-8")


def read_text(path: Path, max_chars: int = 14000) -> str:
    if not path.exists():
        return f"文件不存在：{path}"
    text = path.read_text("utf-8", errors="ignore")
    return text[:max_chars]


def show_gif(path: Path, caption: str = ""):
    if not path.exists():
        st.warning(f"还没有生成：{path.name}")
        return
    data = base64.b64encode(path.read_bytes()).decode("ascii")
    st.markdown(
        f"<img src='data:image/gif;base64,{data}' style='max-width:100%; border:1px solid #e2e8f0; border-radius:10px;'/>" +
        (f"<div class='small-note'>{caption}</div>" if caption else ""),
        unsafe_allow_html=True,
    )


def show_png(path: Path, caption: str = ""):
    if not path.exists():
        st.warning(f"还没有生成：{path.name}")
        return
    st.image(str(path), caption=caption, use_container_width=True)


def preview_csv(path: Path, limit: int = 8):
    if not path.exists():
        st.warning(f"还没有生成 CSV：{path.name}")
        return
    with path.open("r", encoding="utf-8", errors="ignore") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        st.warning("CSV 是空的。")
        return
    st.write(f"共 {len(rows)} 行，下面显示前 {min(limit, len(rows))} 行和最后 1 行。")
    st.table(rows[:limit])
    st.write("最后一行：")
    st.table([rows[-1]])


def file_status(path: Path) -> str:
    if not path.exists():
        return "❌ 缺失"
    size = path.stat().st_size / 1024 / 1024
    return f"✅ {size:.1f} MB"


st.title("🤖 三平台仿真实战：每个平台都看 Franka 抓方块 + AGV 导航寻物")
st.markdown(
    "本页是云实验统一入口。授课顺序固定为：**Swift：Franka 与 AGV → MuJoCo：Franka 与 AGV → Isaac Sim：Franka 与 AGV**。"
    "同一类任务在不同平台中反复出现，学员就能看出：平台差异不是名字，而是模型文件、控制接口、仿真步和可视化证据不同。"
)

cols = st.columns(5)
cols[0].metric("Swift/Panda 日志", file_status(LOGS / "01_swift_panda_pick_cube_headless.log"))
cols[1].metric("Swift/AGV GIF", file_status(OUTPUTS / "swift_agv_navigation.gif"))
cols[2].metric("MuJoCo/Panda GIF", file_status(OUTPUTS / "mujoco_panda_pick_cube.gif"))
cols[3].metric("MuJoCo/AGV GIF", file_status(OUTPUTS / "mujoco_agv_navigation.gif"))
cols[4].metric("运行目录", ROOT.name)

tabs = st.tabs(["0. 云实验入口", "1. Swift", "2. MuJoCo", "3. Isaac Sim", "4. 讲稿/练习"])

with tabs[0]:
    st.header("0. 云实验入口：只开一个 Streamlit 端口")
    st.write("推荐启动命令：")
    code_block("""cd robot_sim_lab_panda_agv_110min
streamlit run streamlit_robot_sim_lab.py \
  --server.port=8501 \
  --server.address=0.0.0.0 \
  --server.headless=true \
  --server.enableCORS=false \
  --server.enableXsrfProtection=false""")
    st.info("云实验中不要直接访问终端打印的 External URL。请在右侧端口管理中选择 8501，点击“查看预览”或复制平台生成的 HTTPS 代理链接。")

    st.subheader("一键检查依赖")
    if st.button("检查 Python / MuJoCo / Robotics Toolbox / Pillow / Streamlit", key="check_env"):
        with st.spinner("正在检查依赖..."):
            code = """
import sys
print('python=', sys.version)
for m in ['numpy','roboticstoolbox','spatialmath','spatialgeometry','mujoco','PIL','streamlit']:
    try:
        mod=__import__(m)
        print('[OK]', m, getattr(mod, '__version__', ''))
    except Exception as e:
        print('[NO]', m, type(e).__name__, e)
"""
            rc, out = run_command([sys.executable, "-c", code], timeout=40)
            st.code(out)
            save_log("streamlit_check_env.log", out)
    with st.expander("项目 README", expanded=False):
        st.markdown(read_text(ROOT / "README.md", max_chars=24000))

with tabs[1]:
    st.header("1. Swift：Franka 抓方块 + AGV 导航寻物")
    st.subheader("1.1 Swift / Robotics Toolbox：Franka Panda 抓方块")
    st.write("Swift 适合先讲清楚机器人身体模型、FK/IK、q_target、P 控制器和 tool0；它更像运动学实验台。")
    code_block("python 01_swift_panda_pick_cube.py --headless")
    if st.button("运行 Swift Panda headless 验证", key="run_swift"):
        with st.spinner("正在运行 Swift Panda。首次导入 Robotics Toolbox 可能较慢..."):
            rc, out = run_command([sys.executable, "01_swift_panda_pick_cube.py", "--headless"], timeout=90)
            save_log("streamlit_01_swift_panda_pick_cube_headless.log", out)
            st.success("运行完成" if rc == 0 else f"运行结束，returncode={rc}")
            st.code(out)
    st.code(read_text(LOGS / "01_swift_panda_pick_cube_headless.log", max_chars=5000))

    st.subheader("1.2 Swift 原生 3D 可视化怎么开")
    code_block("""python 01_swift_panda_pick_cube.py
# 云实验如支持端口转发，可打开 Swift 的 52000/53000 端口
# 常见浏览器地址：http://localhost:52000/?53000""")
    st.caption("如果端口没有自动出现，就先用 headless 版本讲控制链；Swift 原生 3D 不是本 Streamlit 页面内嵌。")

    st.subheader("1.3 Swift AGV：A* 导航寻物 + Swift 3D 可视化")
    st.write("补全后 Swift 不再只讲思路：`02_swift_agv_navigation.py` 可生成 GIF/CSV，也可用 `--swift` 打开 Swift 原生 3D。")
    left, right = st.columns([1.05, 1.0])
    with left:
        show_gif(OUTPUTS / "swift_agv_navigation.gif", "Swift/RTB AGV：A* 路径、局部传感器视野、target_found。")
    with right:
        st.write("运行命令：")
        code_block("""python 02_swift_agv_navigation.py --record

# 如需 Swift 原生 3D：
python 02_swift_agv_navigation.py --swift""")
        if st.button("重新生成 Swift AGV GIF + CSV", key="run_swift_agv"):
            with st.spinner("正在运行 Swift/RTB AGV 导航寻物..."):
                rc, out = run_command([sys.executable, "02_swift_agv_navigation.py", "--record"], timeout=80)
                save_log("streamlit_02_swift_agv_navigation_record.log", out)
                st.success("运行完成" if rc == 0 else f"运行结束，returncode={rc}")
                st.code(out)
    preview_csv(OUTPUTS / "swift_agv_navigation_log.csv")
    with st.expander("Swift Panda 关键代码", expanded=False):
        st.code(read_text(ROOT / "01_swift_panda_pick_cube.py", max_chars=9000), language="python")
    with st.expander("Swift AGV 关键代码", expanded=False):
        st.code(read_text(ROOT / "02_swift_agv_navigation.py", max_chars=11000), language="python")

with tabs[2]:
    st.header("2. MuJoCo：Franka 抓方块 + AGV 导航寻物")
    st.subheader("2.1 MuJoCo Franka Panda + cube")
    left, right = st.columns([1.05, 1.0])
    with left:
        show_gif(OUTPUTS / "mujoco_panda_pick_cube.gif", "MuJoCo Panda 抓方块 GIF：MJCF 模型 + qpos/qvel/ctrl + mj_step。")
    with right:
        st.write("运行命令：")
        code_block("python 03_mujoco_panda_pick_cube.py --record")
        if st.button("重新生成 MuJoCo Panda GIF + CSV", key="run_mujoco_panda"):
            with st.spinner("正在运行 MuJoCo Panda record，可能需要几十秒..."):
                rc, out = run_command([sys.executable, "03_mujoco_panda_pick_cube.py", "--record"], timeout=180)
                save_log("streamlit_03_mujoco_panda_pick_cube_record.log", out)
                st.success("运行完成" if rc == 0 else f"运行结束，returncode={rc}")
                st.code(out)
    preview_csv(OUTPUTS / "mujoco_panda_pick_log.csv")

    st.subheader("2.2 MuJoCo AGV 导航寻物")
    left, right = st.columns([1.05, 1.0])
    with left:
        show_gif(OUTPUTS / "mujoco_agv_navigation.gif", "同样进入 MuJoCo：AGV 有平面位姿，障碍物和目标是 MJCF body/geom。")
    with right:
        st.write("运行命令：")
        code_block("python 04_mujoco_agv_navigation.py --record")
        if st.button("重新生成 MuJoCo AGV GIF + CSV", key="run_mujoco_agv"):
            with st.spinner("正在运行 MuJoCo AGV 导航寻物..."):
                rc, out = run_command([sys.executable, "04_mujoco_agv_navigation.py", "--record"], timeout=120)
                save_log("streamlit_04_mujoco_agv_navigation_record.log", out)
                st.success("运行完成" if rc == 0 else f"运行结束，returncode={rc}")
                st.code(out)
    preview_csv(OUTPUTS / "mujoco_agv_navigation_log.csv")

    with st.expander("MuJoCo Panda 关键代码", expanded=False):
        st.code(read_text(ROOT / "03_mujoco_panda_pick_cube.py", max_chars=9000), language="python")
    with st.expander("MuJoCo AGV 关键代码", expanded=False):
        st.code(read_text(ROOT / "04_mujoco_agv_navigation.py", max_chars=11000), language="python")

with tabs[3]:
    st.header("3. Isaac Sim：Franka 抓方块 + AGV 导航寻物")
    st.warning("Isaac Sim 必须使用 Isaac 自带 python.sh。Streamlit 页面负责讲清命令和代码结构；真正运行要在安装 Isaac Sim 的 GPU 环境中执行。")
    isaac_path = os.environ.get("ISAACSIM_PATH", "")
    st.write("当前 `ISAACSIM_PATH`：", isaac_path or "未设置")
    if st.button("检查 Isaac Sim 路径", key="check_isaac"):
        if not isaac_path:
            st.error("未设置 ISAACSIM_PATH。请在云实验环境中设置 Isaac Sim 安装路径。")
        else:
            pysh = Path(isaac_path) / "python.sh"
            st.write("python.sh：", pysh)
            st.write("状态：", "✅ 存在" if pysh.exists() else "❌ 不存在")

    st.subheader("3.1 Isaac Sim Franka Panda PickPlaceController")
    code_block("${ISAACSIM_PATH}/python.sh 05_isaac_panda_pick_cube.py")
    st.write("讲解链路：SimulationApp → World → Franka → Cube → PickPlaceController → ArticulationAction → world.step(render=True)。")
    with st.expander("Isaac Sim Franka 脚本源码", expanded=False):
        st.code(read_text(ROOT / "05_isaac_panda_pick_cube.py", max_chars=11000), language="python")

    st.subheader("3.2 Isaac Sim AGV / Jetbot 导航寻物")
    code_block("${ISAACSIM_PATH}/python.sh 06_isaac_agv_navigation.py")
    st.write("讲解链路：A* waypoint → [线速度, 角速度] → DifferentialController → 左右轮动作 → world.step(render=True)。")
    st.info("这里用官方 Jetbot USD 作为差速轮 AGV 教学载体；如果版本 API 有变化，课堂按这条控制链排查即可。")
    with st.expander("Isaac Sim AGV 脚本源码", expanded=True):
        st.code(read_text(ROOT / "06_isaac_agv_navigation.py", max_chars=14000), language="python")

with tabs[4]:
    st.header("4. 讲稿 / 练习 / 平台对比")
    doc_names = [
        "课堂讲稿_110分钟.md",
        "课堂练习与答案.md",
        "平台对比速查表.md",
        "技术背景.md",
        "技术栈.md",
        "运行环境.md",
        "项目框架.md",
        "项目简介_学员端.md",
        "参考来源.md",
    ]
    selected = st.selectbox("选择文档", doc_names)
    st.markdown(read_text(DOCS / selected, max_chars=26000))

st.divider()
st.markdown("<span class='small-note'>课堂提醒：Streamlit 是统一入口；Swift/MuJoCo 可在页面内生成 GIF/CSV；Isaac Sim 的运行必须交给 Isaac 自带 python.sh；Swift 原生 3D 需要额外端口。</span>", unsafe_allow_html=True)
