"""Isaac Sim：AGV/Jetbot 导航寻物脚本。

运行必须使用 Isaac Sim 自带 Python：
  ${ISAACSIM_PATH}/python.sh 06_isaac_agv_navigation.py

课堂主线：
  World/Stage -> WheeledRobot(AGV) -> DifferentialController -> wheel_actions -> world.step(render=True)

说明：
- 这里用 Isaac Sim 官方 Jetbot USD 作为“差速轮 AGV”教学载体；
- 先用 A* 在二维栅格里生成 waypoint，再把 waypoint 转成 Isaac 世界坐标；
- DifferentialController 把 [线速度, 角速度] 转成左右轮速度；
- 每一步记录 AGV pose、当前 waypoint、目标距离，便于课堂复盘。

如果你的 Isaac Sim 版本 API 有变化，请优先对照 NVIDIA 官方 mobile robot controller / wheeled robot 示例。
"""
from __future__ import annotations

import argparse
import csv
import math
from collections import deque
from pathlib import Path
from typing import Iterable

import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument("--headless", action="store_true", help="无界面运行；云桌面展示时不要加这个参数。")
parser.add_argument("--steps", type=int, default=1800, help="最大仿真步数。")
parser.add_argument("--render-every", type=int, default=1, help="每隔多少步渲染一次。")
args = parser.parse_args()

# Isaac Sim 要求 SimulationApp 尽量早创建，然后再 import Isaac 相关模块。
try:
    from isaacsim import SimulationApp  # noqa: E402
except ModuleNotFoundError as exc:
    raise SystemExit('普通 Python 环境没有 Isaac Sim 运行时，不能直接用 `python 05_isaac_panda_pick_cube.py` 或 `python 06_isaac_agv_navigation.py` 运行。\n\n正确方式是在安装 Isaac Sim 的机器上，用 Isaac Sim 自带 Python 启动，例如：\n\n  ${ISAACSIM_PATH}/python.sh 05_isaac_panda_pick_cube.py\n  ${ISAACSIM_PATH}/python.sh 06_isaac_agv_navigation.py\n\n如果不知道 ISAACSIM_PATH，可在 Linux/云服务器上尝试查找：\n\n  find ~/.local/share/ov/pkg /opt -name python.sh 2>/dev/null | grep -i isaac\n\n注意：Mac 本机通常不能直接运行 Isaac Sim 3D 仿真；课堂展示建议在装有 NVIDIA GPU 和 Isaac Sim 的云实验/服务器上运行。\n') from exc

simulation_app = SimulationApp({"headless": args.headless})

try:  # Isaac Sim 5.x/6.x 常见路径
    from isaacsim.core.api import World
    from isaacsim.core.api.objects import DynamicCuboid, VisualCuboid
    from isaacsim.storage.native import get_assets_root_path
    from isaacsim.robot.wheeled_robots.robots import WheeledRobot
    from isaacsim.robot.wheeled_robots.controllers.differential_controller import DifferentialController
except Exception:  # 旧版 Omniverse Isaac Sim 路径
    try:
        from omni.isaac.core import World
        from omni.isaac.core.objects import DynamicCuboid, VisualCuboid
        from omni.isaac.core.utils.nucleus import get_assets_root_path
        from omni.isaac.wheeled_robots.robots import WheeledRobot
        from omni.isaac.wheeled_robots.controllers.differential_controller import DifferentialController
    except Exception as exc:
        simulation_app.close()
        raise RuntimeError(
            "当前 Isaac Sim 环境未找到 WheeledRobot/DifferentialController。"
            "请检查是否启用 isaacsim.robot.wheeled_robots 扩展，或按官方 Jetbot differential 示例运行。"
        ) from exc

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)
LOG_PATH = OUT / "isaac_agv_navigation_log.csv"

# 16x10 栅格：0 可通行，1 障碍物。坐标采用 grid(row, col)。
GRID = np.zeros((10, 16), dtype=int)
GRID[2:8, 4] = 1
GRID[1:5, 9] = 1
GRID[6, 8:13] = 1
START_GRID = (1, 1)
GOAL_GRID = (7, 13)
CELL = 0.16  # 每个格子映射为 Isaac 世界中的 0.16m
ORIGIN_XY = np.array([-1.15, -0.75])


def astar(grid: np.ndarray, start: tuple[int, int], goal: tuple[int, int]) -> list[tuple[int, int]]:
    """小型 A*：为课堂保持透明，不引入额外路径规划库。"""
    h, w = grid.shape

    def nb(p: tuple[int, int]) -> Iterable[tuple[int, int]]:
        r, c = p
        for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            rr, cc = r + dr, c + dc
            if 0 <= rr < h and 0 <= cc < w and grid[rr, cc] == 0:
                yield rr, cc

    def manhattan(p: tuple[int, int]) -> int:
        return abs(p[0] - goal[0]) + abs(p[1] - goal[1])

    open_set = {start}
    came: dict[tuple[int, int], tuple[int, int]] = {}
    g = {start: 0}
    f = {start: manhattan(start)}
    while open_set:
        cur = min(open_set, key=lambda p: f.get(p, 10**9))
        if cur == goal:
            path = [cur]
            while cur in came:
                cur = came[cur]
                path.append(cur)
            return list(reversed(path))
        open_set.remove(cur)
        for nxt in nb(cur):
            tentative = g[cur] + 1
            if tentative < g.get(nxt, 10**9):
                came[nxt] = cur
                g[nxt] = tentative
                f[nxt] = tentative + manhattan(nxt)
                open_set.add(nxt)
    return []


def grid_to_world(cell_rc: tuple[int, int]) -> np.ndarray:
    """grid(row, col) -> Isaac world x/y。row 映射到 y，col 映射到 x。"""
    r, c = cell_rc
    return np.array([ORIGIN_XY[0] + c * CELL, ORIGIN_XY[1] + r * CELL, 0.03])


def yaw_from_quat(q) -> float:
    """Isaac 常用四元数顺序为 [w, x, y, z]，这里取平面 yaw。"""
    q = np.asarray(q, dtype=float)
    if q.shape[0] != 4:
        return 0.0
    w, x, y, z = q
    return math.atan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z))


def wrap_to_pi(a: float) -> float:
    return (a + math.pi) % (2 * math.pi) - math.pi


path_grid = astar(GRID, START_GRID, GOAL_GRID)
if not path_grid:
    raise RuntimeError("A* 没有找到路径，请检查 GRID。")
waypoints = [grid_to_world(p) for p in path_grid]
goal_world = waypoints[-1]

assets_root = get_assets_root_path()
if assets_root is None:
    simulation_app.close()
    raise RuntimeError("Could not find Isaac Sim assets folder. 请检查 Nucleus/本地 Isaac 资产路径。")

# Isaac Sim 版本间 Jetbot 路径略有差异，按常见路径依次尝试。
JETBOT_CANDIDATES = [
    assets_root + "/Isaac/Robots/NVIDIA/Jetbot/jetbot.usd",
    assets_root + "/Isaac/Robots/Jetbot/jetbot.usd",
]
jetbot_usd = JETBOT_CANDIDATES[0]

world = World(stage_units_in_meters=1.0)
world.scene.add_default_ground_plane()

# 障碍物与目标：用 cuboid 把二维地图转成可见三维环境。
for r in range(GRID.shape[0]):
    for c in range(GRID.shape[1]):
        if GRID[r, c] == 1:
            pos = grid_to_world((r, c))
            pos[2] = 0.06
            world.scene.add(
                DynamicCuboid(
                    prim_path=f"/World/Obstacle_{r}_{c}",
                    name=f"obstacle_{r}_{c}",
                    position=pos,
                    scale=np.array([CELL * 0.85, CELL * 0.85, 0.12]),
                    color=np.array([0.35, 0.35, 0.38]),
                )
            )

world.scene.add(
    VisualCuboid(
        prim_path="/World/SearchTarget",
        name="search_target",
        position=np.array([goal_world[0], goal_world[1], 0.08]),
        scale=np.array([0.10, 0.10, 0.10]),
        color=np.array([1.0, 0.10, 0.05]),
    )
)

# Waypoint 用一串薄片标出来，方便课堂解释“规划路径”和“物理机器人跟踪路径”不是一回事。
for i, wp in enumerate(waypoints):
    world.scene.add(
        VisualCuboid(
            prim_path=f"/World/Waypoint_{i:02d}",
            name=f"waypoint_{i:02d}",
            position=np.array([wp[0], wp[1], 0.012]),
            scale=np.array([0.045, 0.045, 0.008]),
            color=np.array([0.1, 0.55, 1.0]),
        )
    )

agv = world.scene.add(
    WheeledRobot(
        prim_path="/World/AGV",
        name="agv",
        wheel_dof_names=["left_wheel_joint", "right_wheel_joint"],
        create_robot=True,
        usd_path=jetbot_usd,
        position=grid_to_world(START_GRID),
    )
)

controller = DifferentialController(name="agv_diff_controller", wheel_radius=0.03, wheel_base=0.1125)
world.reset()

wp_queue = deque(waypoints[1:])
current_wp = wp_queue[0]
rows = []
print("Isaac Sim AGV navigation search")
print("jetbot_usd=", jetbot_usd)
print("path_grid=", path_grid)
print("goal_world=", np.round(goal_world, 3))
print("控制链：A* waypoint -> [linear_speed, angular_speed] -> DifferentialController -> wheel_actions -> world.step(render=True)")

for step in range(args.steps):
    pos, ori = agv.get_world_pose()
    pos = np.asarray(pos, dtype=float)
    yaw = yaw_from_quat(ori)

    delta = current_wp[:2] - pos[:2]
    dist = float(np.linalg.norm(delta))
    heading = math.atan2(delta[1], delta[0])
    yaw_error = wrap_to_pi(heading - yaw)

    if dist < 0.07 and len(wp_queue) > 1:
        wp_queue.popleft()
        current_wp = wp_queue[0]
        delta = current_wp[:2] - pos[:2]
        dist = float(np.linalg.norm(delta))
        heading = math.atan2(delta[1], delta[0])
        yaw_error = wrap_to_pi(heading - yaw)

    final_dist = float(np.linalg.norm(goal_world[:2] - pos[:2]))
    found = final_dist < 0.12

    # 简单路径跟踪：先转向，朝向接近后再前进。
    angular = float(np.clip(2.2 * yaw_error, -1.4, 1.4))
    linear = 0.22 if abs(yaw_error) < 0.65 else 0.05
    if found:
        linear, angular = 0.0, 0.0

    wheel_action = controller.forward(command=np.array([linear, angular]))
    try:
        agv.apply_wheel_actions(wheel_action)
    except AttributeError:
        agv.get_articulation_controller().apply_action(wheel_action)

    render = (step % max(args.render_every, 1) == 0) and not args.headless
    world.step(render=render)

    rows.append(
        {
            "step": step,
            "x": round(float(pos[0]), 4),
            "y": round(float(pos[1]), 4),
            "yaw": round(yaw, 4),
            "waypoint_x": round(float(current_wp[0]), 4),
            "waypoint_y": round(float(current_wp[1]), 4),
            "distance_to_waypoint": round(dist, 4),
            "distance_to_goal": round(final_dist, 4),
            "linear_cmd": round(linear, 4),
            "angular_cmd": round(angular, 4),
            "target_found": found,
        }
    )
    if step % 120 == 0:
        print(f"step={step:04d} pos=({pos[0]:.2f},{pos[1]:.2f}) wp=({current_wp[0]:.2f},{current_wp[1]:.2f}) goal_dist={final_dist:.2f} found={found}")
    if found:
        print("AGV found target at step", step)
        break

with LOG_PATH.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)
print("saved log:", LOG_PATH)
print("课堂讲解重点：Isaac Sim 的 AGV 不是手改 x/y，而是把线速度/角速度交给差速控制器，再由物理步推进。")
simulation_app.close()
