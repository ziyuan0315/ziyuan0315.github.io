"""MuJoCo viewer 在 macOS 上的启动兼容处理。

MuJoCo 官方 viewer 在 macOS 上要求用 `mjpython` 启动，而不是普通 `python`。
否则会报：
    RuntimeError: `launch_passive` requires that the Python script be run under `mjpython` on macOS

本工具函数用于课程脚本：当用户在 macOS 上用 `python xxx.py --viewer` 启动时，
自动切换为 `mjpython xxx.py --viewer`；如果环境找不到 mjpython，则给出清晰提示。
"""
from __future__ import annotations

import os
import platform
import shutil
import sys
from pathlib import Path


def ensure_mjpython_for_macos_viewer(script_file: str) -> None:
    """macOS + MuJoCo viewer 时，确保当前进程由 mjpython 启动。"""
    if platform.system() != "Darwin":
        return

    exe_name = Path(sys.executable).name.lower()
    if exe_name == "mjpython":
        return

    mjpython = shutil.which("mjpython")
    if not mjpython:
        raise SystemExit(
            "MuJoCo viewer 在 macOS 上必须用 mjpython 启动。\n\n"
            "当前命令使用的是普通 python，因此会触发 launch_passive 报错。\n"
            "请先确认 mujoco 已正确安装，并在终端运行：\n\n"
            f"  mjpython {Path(script_file).name} --viewer\n\n"
            "如果系统提示找不到 mjpython，请执行：\n\n"
            "  python -m pip install -U mujoco\n"
        )

    # 防御性保护：避免极端情况下重复 exec。
    if os.environ.get("ROBOT_SIM_LAB_MJPYTHON_REEXEC") == "1":
        return

    env = os.environ.copy()
    env["ROBOT_SIM_LAB_MJPYTHON_REEXEC"] = "1"
    cmd = [mjpython, str(Path(script_file).resolve()), *sys.argv[1:]]
    print("检测到 macOS + MuJoCo viewer：自动切换到 mjpython 启动。")
    print("执行：", " ".join(cmd))
    os.execve(mjpython, cmd, env)
