"""Swift/Robotics Toolbox：Franka Panda 抓方块最小完整可视化。

运行：
  python 01_swift_panda_pick_cube.py
云平台端口映射：
  -L 52000:localhost:52000 -L 53000:localhost:53000
浏览器：
  http://localhost:52000/?53000

教学重点：
- 机器人：Franka Panda 7 自由度机械臂；
- 任务：home -> pre_grasp -> grasp -> lift -> place；
- 规划：用 IK 把末端目标位姿转成 q_target；
- 控制：关节空间 P 控制器 qdot = k(q_target - q)；
- 抓取：Swift 没有接触物理，本脚本用“到达后绑定 cube 到 tool”稳定展示任务链。
"""
import argparse
import time
import numpy as np
import roboticstoolbox as rtb
import spatialgeometry as sg
from spatialmath import SE3
from swift_compat import patch_swift_websockets


def solve_ik(robot, T, q0):
    sol = robot.ikine_LM(T, q0=q0, ilimit=100, slimit=50)
    if not sol.success:
        raise RuntimeError(f"IK failed: {sol.reason}")
    return sol.q


def move_to(robot, env, q_target, cube=None, attached=False, steps=120, dt=0.025, gain=3.2):
    """关节空间 P 控制器。每一步只改一点 q，再 env.step 刷新 Swift。"""
    trace = []
    for _ in range(steps):
        err = q_target - robot.q
        qdot = np.clip(gain * err, -1.0, 1.0)
        robot.q = robot.q + qdot * dt
        tool = robot.fkine(robot.q)
        if attached and cube is not None:
            # Swift 教学版稳定抓取：方块跟随 tool0，保留可视化任务链。
            cube.T = (SE3(tool.t) * SE3(0, 0, -0.10)).A
        env.step(dt)
        trace.append(tool.t.copy())
        time.sleep(dt)
    return np.array(trace)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--headless', action='store_true')
    parser.add_argument('--cube', nargs=3, type=float, default=[0.45, 0.20, 0.05], metavar=('X','Y','Z'))
    parser.add_argument('--place', nargs=3, type=float, default=[0.35, -0.25, 0.05], metavar=('X','Y','Z'))
    args = parser.parse_args()

    patched = patch_swift_websockets()
    if patched:
        print("已应用 Swift/websockets 兼容补丁：当前环境 websockets 版本较新。")
    import swift
    robot = rtb.models.Panda()
    robot.q = robot.qr.copy()

    env = swift.Swift()
    env.launch(realtime=True, headless=args.headless)
    env.add(robot)

    table = sg.Cuboid([0.9, 0.8, 0.03], pose=SE3(0.45, 0.0, -0.015), color=[0.78,0.80,0.82,0.55])
    cube = sg.Cuboid([0.055, 0.055, 0.055], pose=SE3(*args.cube), color=[1.0,0.12,0.06,1])
    place_marker = sg.Sphere(0.035, pose=SE3(*args.place), color=[0.05,0.9,0.25,1])
    env.add(table); env.add(cube); env.add(place_marker)

    # 末端竖直向下：位置 + 姿态一起构成 grasp pose。
    def grasp_T(xyz, dz):
        return SE3(xyz[0], xyz[1], xyz[2] + dz) * SE3.Rx(np.pi)

    q_home = robot.qr.copy()
    q_pre = solve_ik(robot, grasp_T(args.cube, 0.23), q_home)
    q_grasp = solve_ik(robot, grasp_T(args.cube, 0.12), q_pre)
    q_lift = solve_ik(robot, grasp_T(args.cube, 0.32), q_grasp)
    q_place = solve_ik(robot, grasp_T(args.place, 0.18), q_lift)

    print('Swift Panda pick cube scene')
    print('端口：HTTP 52000 + WebSocket 53000；浏览器 http://localhost:52000/?53000')
    for name, q in [('home',q_home), ('pre_grasp',q_pre), ('grasp',q_grasp), ('lift',q_lift), ('place',q_place)]:
        print(name, 'q(deg)=', np.round(np.rad2deg(q), 2), 'tool=', np.round(robot.fkine(q).t, 3))

    move_to(robot, env, q_pre)
    move_to(robot, env, q_grasp)
    print('close gripper: 教学版绑定 cube 到 tool0')
    move_to(robot, env, q_lift, cube=cube, attached=True)
    move_to(robot, env, q_place, cube=cube, attached=True)
    print('open gripper: 释放方块')
    move_to(robot, env, q_home, cube=cube, attached=False)

    if not args.headless:
        input('演示结束，按回车关闭 Swift...')
        env.close()
    else:
        print('headless 模式完成：已验证 IK、控制器和任务链。')


if __name__ == '__main__':
    main()
