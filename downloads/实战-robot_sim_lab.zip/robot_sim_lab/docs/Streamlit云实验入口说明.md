# Streamlit 云实验入口说明

本代码包已经提供统一浏览器入口：`streamlit_robot_sim_lab.py`。

## 启动命令

```bash
cd robot_sim_lab_panda_agv_110min
streamlit run streamlit_robot_sim_lab.py \
  --server.port=8501 \
  --server.address=0.0.0.0 \
  --server.headless=true \
  --server.enableCORS=false \
  --server.enableXsrfProtection=false
```

也可以直接运行：

```bash
bash run_streamlit_cloud.sh
```

## 打开方式

在云实验右侧端口管理中选择 `8501`，点击“查看预览”。

不要直接打开终端打印的：

```text
External URL: http://公网IP:8501
```

很多云实验平台的公网端口并不直接暴露，必须走平台生成的 HTTPS 代理链接。

## 页面结构

- `0. 云实验入口`：检查依赖、查看 README。
- `1. Swift Panda`：运行 headless 验证，展示 IK 和控制器日志。
- `2. MuJoCo Panda`：展示/重新生成抓方块 GIF 和 CSV 状态证据。
- `3. Isaac Sim`：展示 Isaac Sim 命令、检查 `ISAACSIM_PATH`、查看源码。
- `4. AGV 导航`：展示/重新生成 A* 导航寻物 GIF。
- `5. 讲稿/练习`：直接浏览课堂讲稿、练习答案和平台对比表。

## 课堂建议

如果只给学生一个命令，就给 Streamlit 命令。学生先通过浏览器理解整体任务，再按老师要求进入具体脚本查看源码。
