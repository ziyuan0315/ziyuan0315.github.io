"""Swift 可视化在新版 websockets 下的兼容补丁。

背景：
Robotics Toolbox 的 swift 包当前仍按旧版 websockets API 启动 WebSocket。
当环境里安装 websockets 15/16 时，`websockets.serve(...)` 会要求当前线程
已经有 running event loop，导致：RuntimeError: no running event loop。

处理：
把 websockets.serve 切回 websockets.legacy.server.serve。
这只影响本课程脚本启动 Swift 可视化服务，不改变机器人工具箱计算逻辑。
"""
from __future__ import annotations


def patch_swift_websockets() -> bool:
    """兼容 websockets>=15 与 swift.SwiftRoute。

    返回 True 表示已应用补丁；False 表示当前环境无需或无法应用。
    """
    try:
        import websockets
        from websockets.legacy.server import serve as legacy_serve
    except Exception:
        return False

    # websockets 15/16 顶层 serve 使用 asyncio.get_running_loop()，
    # swift.SwiftRoute 是在线程中先创建 loop 再 run_until_complete，
    # 因此需要旧版 serve 行为。
    try:
        major = int(str(getattr(websockets, "__version__", "0")).split(".")[0])
    except Exception:
        major = 0

    if major >= 15:
        websockets.serve = legacy_serve  # type: ignore[attr-defined]
        return True
    return False
