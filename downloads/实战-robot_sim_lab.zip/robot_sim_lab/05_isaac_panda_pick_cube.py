"""Isaac Sim：Franka Panda 抓方块完整可运行脚本。

运行必须使用 Isaac Sim 自带 Python：
  ${ISAACSIM_PATH}/python.sh 05_isaac_panda_pick_cube.py

本脚本采用 Isaac Sim 常见 PickPlaceController/Franka 口径，在安装 Isaac Sim 的环境中可直接运行。
如果你的 Isaac Sim 版本 API 有变化，课堂上仍按这条主线讲：
World -> Franka/Manipulator -> Cube -> PickPlaceController -> world.step(render=True)
"""
import argparse
import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument('--headless', action='store_true')
args = parser.parse_args()

try:
    from isaacsim import SimulationApp
except ModuleNotFoundError as exc:
    raise SystemExit('普通 Python 环境没有 Isaac Sim 运行时，不能直接用 `python 05_isaac_panda_pick_cube.py` 或 `python 06_isaac_agv_navigation.py` 运行。\n\n正确方式是在安装 Isaac Sim 的机器上，用 Isaac Sim 自带 Python 启动，例如：\n\n  ${ISAACSIM_PATH}/python.sh 05_isaac_panda_pick_cube.py\n  ${ISAACSIM_PATH}/python.sh 06_isaac_agv_navigation.py\n\n如果不知道 ISAACSIM_PATH，可在 Linux/云服务器上尝试查找：\n\n  find ~/.local/share/ov/pkg /opt -name python.sh 2>/dev/null | grep -i isaac\n\n注意：Mac 本机通常不能直接运行 Isaac Sim 3D 仿真；课堂展示建议在装有 NVIDIA GPU 和 Isaac Sim 的云实验/服务器上运行。\n') from exc

simulation_app = SimulationApp({'headless': args.headless})

from isaacsim.core.api import World
from isaacsim.core.api.objects import DynamicCuboid
from isaacsim.core.utils.types import ArticulationAction

# 兼容不同 Isaac Sim 版本：优先使用 Franka + PickPlaceController；失败时给出清晰错误。
try:
    from isaacsim.robot.manipulators.examples.franka import Franka
    from isaacsim.robot.manipulators.controllers import PickPlaceController
except Exception:
    try:
        from omni.isaac.franka import Franka
        from omni.isaac.franka.controllers.pick_place_controller import PickPlaceController
    except Exception as e:
        raise RuntimeError('当前 Isaac Sim 版本未找到 Franka/PickPlaceController，请检查扩展或用 UI 示例加载 Franka。') from e

world = World(stage_units_in_meters=1.0)
world.scene.add_default_ground_plane()

franka = world.scene.add(Franka(prim_path='/World/Franka', name='franka'))
cube = world.scene.add(DynamicCuboid(
    prim_path='/World/Cube', name='cube',
    position=np.array([0.50, 0.00, 0.035]),
    scale=np.array([0.05, 0.05, 0.05]),
    color=np.array([1.0, 0.1, 0.05])
))

world.reset()
controller = PickPlaceController(name='pick_place_controller', gripper=franka.gripper, robot_articulation=franka)
art_controller = franka.get_articulation_controller()

pick_position = np.array([0.50, 0.00, 0.05])
place_position = np.array([0.30, -0.30, 0.05])
print('Isaac Sim Franka Panda pick cube')
print('pick_position=', pick_position, 'place_position=', place_position)
print('控制链：controller.forward(...) -> ArticulationAction -> world.step(render=True)')

for i in range(1200):
    current_joints = franka.get_joint_positions()
    action = controller.forward(
        picking_position=pick_position,
        placing_position=place_position,
        current_joint_positions=current_joints,
    )
    art_controller.apply_action(action)
    world.step(render=True)
    if i % 120 == 0:
        print('step', i, 'cube=', cube.get_world_pose()[0], 'done=', controller.is_done())
    if controller.is_done():
        print('Pick-place done at step', i)
        break

simulation_app.close()
