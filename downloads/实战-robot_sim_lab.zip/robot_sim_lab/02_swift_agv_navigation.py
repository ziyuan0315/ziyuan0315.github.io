"""Swift / Robotics Toolbox：AGV 导航寻物完整可运行示例。

运行方式：
  # 生成课堂可展示 GIF/CSV，适合云实验 Streamlit 页面直接展示
  python 02_swift_agv_navigation.py --record

  # 打开 Swift 原生 3D，可通过 52000/53000 端口映射到浏览器
  python 02_swift_agv_navigation.py --swift

教学重点：
- AGV 不是 FK/IK 主导，而是 map、pose、path、sensor_range 和 target_found；
- A* 负责在地图上生成 waypoint；
- Swift 负责把 AGV、障碍物、目标和传感器视野放进可视化世界；
- GIF/CSV 负责留下可复盘证据。
"""
from __future__ import annotations

import argparse
import csv
import math
import time
from heapq import heappop, heappush
from pathlib import Path

from PIL import Image, ImageDraw
from swift_compat import patch_swift_websockets

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs"
LOGS = ROOT / "run_logs"
OUT.mkdir(exist_ok=True)
LOGS.mkdir(exist_ok=True)

W, H = 16, 10
START = (1, 1)
SEARCH_GOAL = (12, 6)
TARGET = (13, 7)
SENSOR_RANGE = 2.2
OBSTACLES = {(5, y) for y in range(1, 8)} | {(9, y) for y in range(2, 9)} | {(x, 4) for x in range(9, 14)}
OBSTACLES -= {(5, 5), (9, 7)}


def neighbors(p: tuple[int, int]):
    x, y = p
    for nx, ny in [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]:
        if 0 <= nx < W and 0 <= ny < H and (nx, ny) not in OBSTACLES:
            yield nx, ny


def heuristic(a: tuple[int, int], b: tuple[int, int]) -> float:
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def astar(start: tuple[int, int], goal: tuple[int, int]) -> list[tuple[int, int]]:
    pq: list[tuple[float, tuple[int, int]]] = []
    heappush(pq, (0, start))
    came = {start: None}
    cost = {start: 0}
    while pq:
        _, cur = heappop(pq)
        if cur == goal:
            break
        for nb in neighbors(cur):
            nc = cost[cur] + 1
            if nb not in cost or nc < cost[nb]:
                cost[nb] = nc
                heappush(pq, (nc + heuristic(nb, goal), nb))
                came[nb] = cur
    if goal not in came:
        return []
    path = []
    cur = goal
    while cur is not None:
        path.append(cur)
        cur = came[cur]
    return path[::-1]


def grid_to_world(p: tuple[int, int], scale: float = 0.22) -> tuple[float, float, float]:
    """栅格坐标转 Swift 3D 世界坐标，z 固定在地面上方。"""
    x, y = p
    return (x - W / 2) * scale, (H / 2 - y) * scale, 0.055


def draw_frame(path_prefix: list[tuple[int, int]], agv: tuple[int, int], found: bool) -> Image.Image:
    cell = 56
    img = Image.new("RGB", (W * cell, H * cell), (242, 248, 255))
    d = ImageDraw.Draw(img)
    for x in range(W):
        for y in range(H):
            box = [x * cell, y * cell, (x + 1) * cell, (y + 1) * cell]
            fill = (35, 48, 72) if (x, y) in OBSTACLES else (248, 250, 252)
            d.rectangle(box, fill=fill, outline=(203, 213, 225))
    for p in path_prefix:
        x, y = p
        d.rectangle([x * cell + 18, y * cell + 18, x * cell + 38, y * cell + 38], fill=(30, 144, 255))
    tx, ty = TARGET
    d.ellipse([tx * cell + 16, ty * cell + 16, tx * cell + 40, ty * cell + 40], fill=(239, 68, 68) if found else (245, 158, 11))
    ax, ay = agv
    r = int(SENSOR_RANGE * cell)
    center = (ax * cell + cell // 2, ay * cell + cell // 2)
    d.ellipse([center[0] - r, center[1] - r, center[0] + r, center[1] + r], outline=(16, 185, 129), width=4)
    d.rounded_rectangle([ax * cell + 11, ay * cell + 14, ax * cell + 45, ay * cell + 42], radius=7, fill=(59, 130, 246))
    d.text((12, 10), "Swift/RTB AGV: A* path + sensor range + target_found", fill=(15, 23, 42))
    d.text((12, 34), f"pose={agv} target={TARGET} found={found}", fill=(15, 23, 42))
    return img


def record_gif(path: list[tuple[int, int]]):
    frames: list[Image.Image] = []
    rows = []
    found = False
    for i, agv in enumerate(path):
        if math.dist(agv, TARGET) <= SENSOR_RANGE:
            found = True
        frames.append(draw_frame(path[: i + 1], agv, found))
        rows.append({
            "step": i,
            "grid_x": agv[0],
            "grid_y": agv[1],
            "target_x": TARGET[0],
            "target_y": TARGET[1],
            "distance_to_target": round(math.dist(agv, TARGET), 3),
            "sensor_range": SENSOR_RANGE,
            "target_found": found,
        })
    gif = OUT / "swift_agv_navigation.gif"
    preview = OUT / "swift_agv_navigation_preview.png"
    csv_path = OUT / "swift_agv_navigation_log.csv"
    frames[0].save(gif, save_all=True, append_images=frames[1:], duration=280, loop=0)
    frames[-1].save(preview)
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader(); writer.writerows(rows)
    log = LOGS / "02_swift_agv_navigation_record.log"
    log.write_text(
        f"Swift/RTB AGV navigation\npath={path}\nfound={found}\ngif={gif}\ncsv={csv_path}\n",
        encoding="utf-8",
    )
    print("Swift/RTB AGV navigation")
    print("path=", path)
    print("target=", TARGET, "found=", found)
    print("saved gif:", gif)
    print("saved csv:", csv_path)
    print("saved log:", log)


def run_swift_3d(path: list[tuple[int, int]], headless: bool = False):
    patched = patch_swift_websockets()
    if patched:
        print("已应用 Swift/websockets 兼容补丁：当前环境 websockets 版本较新。")
    import swift
    import spatialgeometry as sg
    from spatialmath import SE3

    env = swift.Swift()
    env.launch(realtime=True, headless=headless)

    # 地面、障碍、目标、AGV、传感器视野：都是 Swift 中的可视化对象。
    floor = sg.Cuboid([W * 0.22, H * 0.22, 0.015], pose=SE3(0, 0, -0.01), color=[0.90, 0.94, 0.98, 0.6])
    env.add(floor)
    for x, y in OBSTACLES:
        wx, wy, wz = grid_to_world((x, y))
        env.add(sg.Cuboid([0.20, 0.20, 0.16], pose=SE3(wx, wy, 0.08), color=[0.20, 0.28, 0.40, 1.0]))
    tx, ty, _ = grid_to_world(TARGET)
    target_obj = sg.Sphere(0.07, pose=SE3(tx, ty, 0.07), color=[1.0, 0.20, 0.08, 1.0])
    env.add(target_obj)

    # 不再用一个半透明大绿球表示传感器范围：部分 Swift/浏览器组合会把透明球渲染成实体，
    # 学员会误以为“AGV 是一个绿球”。这里改成“蓝色小车 + 轮子 + 相机柱 + 地面绿点探测圈”。
    agv_body = sg.Cuboid([0.24, 0.15, 0.08], color=[0.10, 0.45, 1.0, 1.0])
    agv_top = sg.Cuboid([0.13, 0.09, 0.055], color=[0.08, 0.25, 0.65, 1.0])
    camera_mast = sg.Cuboid([0.025, 0.025, 0.13], color=[0.05, 0.05, 0.05, 1.0])
    camera_head = sg.Cuboid([0.065, 0.045, 0.035], color=[0.02, 0.02, 0.02, 1.0])
    wheels = [sg.Cuboid([0.055, 0.025, 0.045], color=[0.02, 0.02, 0.025, 1.0]) for _ in range(4)]
    sensor_ring = [sg.Sphere(0.018, color=[0.10, 0.85, 0.45, 1.0]) for _ in range(28)]
    path_marks = []
    for cell in path:
        px, py, _ = grid_to_world(cell)
        mark = sg.Cuboid([0.055, 0.055, 0.01], pose=SE3(px, py, 0.008), color=[0.25, 0.55, 1.0, 0.55])
        path_marks.append(mark)
        env.add(mark)
    for obj in [agv_body, agv_top, camera_mast, camera_head, *wheels, *sensor_ring]:
        env.add(obj)

    def heading_for_step(i: int) -> float:
        """根据路径方向估计 AGV 车头朝向，方便看出它是车而不是几何点。"""
        if i < len(path) - 1:
            a, b = path[i], path[i + 1]
        elif i > 0:
            a, b = path[i - 1], path[i]
        else:
            return 0.0
        ax, ay, _ = grid_to_world(a)
        bx, by, _ = grid_to_world(b)
        return math.atan2(by - ay, bx - ax)

    def local_pose(x: float, y: float, z: float, yaw: float, lx: float, ly: float, lz: float):
        return (SE3(x, y, z) * SE3.Rz(yaw) * SE3(lx, ly, lz)).A

    def update_agv(x: float, y: float, z: float, yaw: float):
        agv_body.T = local_pose(x, y, z, yaw, 0.0, 0.0, 0.04)
        agv_top.T = local_pose(x, y, z, yaw, -0.015, 0.0, 0.105)
        camera_mast.T = local_pose(x, y, z, yaw, 0.105, 0.0, 0.14)
        camera_head.T = local_pose(x, y, z, yaw, 0.145, 0.0, 0.205)
        for wheel, (lx, ly) in zip(wheels, [(-0.07, -0.09), (0.07, -0.09), (-0.07, 0.09), (0.07, 0.09)]):
            wheel.T = local_pose(x, y, z, yaw, lx, ly, 0.02)
        radius = 0.22 * SENSOR_RANGE
        for k, dot in enumerate(sensor_ring):
            a = 2 * math.pi * k / len(sensor_ring)
            dot.T = SE3(x + radius * math.cos(a), y + radius * math.sin(a), 0.025).A

    found = False
    print("Swift 3D AGV navigation")
    print("蓝色小车=AGV；黑色小块=车载相机；绿色点圈=传感器探测范围；橙红球=目标物。")
    print("端口：HTTP 52000 + WebSocket 53000；浏览器 http://localhost:52000/?53000")
    for step, cell in enumerate(path):
        x, y, z = grid_to_world(cell)
        yaw = heading_for_step(step)
        if math.dist(cell, TARGET) <= SENSOR_RANGE:
            found = True
            target_obj.color = [1.0, 0.0, 0.0, 1.0]
        update_agv(x, y, z, yaw)
        print(f"step={step:02d} pose={cell} yaw={round(math.degrees(yaw),1)}deg target_found={found}")
        env.step(0.18)
        time.sleep(0.18)
    if not headless:
        input("演示结束，按回车关闭 Swift...")
    env.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--record", action="store_true", help="生成 GIF/CSV，默认行为。")
    parser.add_argument("--swift", action="store_true", help="打开 Swift 原生 3D。")
    parser.add_argument("--headless", action="store_true", help="Swift 原生 3D 无界面验证。")
    args = parser.parse_args()
    path = astar(START, SEARCH_GOAL)
    if not path:
        raise RuntimeError("A* 没找到路径，请检查障碍物配置。")
    if args.swift:
        run_swift_3d(path, headless=args.headless)
    else:
        record_gif(path)


if __name__ == "__main__":
    main()
