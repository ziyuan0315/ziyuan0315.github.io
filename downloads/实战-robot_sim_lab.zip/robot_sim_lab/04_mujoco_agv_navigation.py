"""MuJoCo：AGV 导航寻物可运行示例。

运行：
  python 04_mujoco_agv_navigation.py --record
  python 04_mujoco_agv_navigation.py --viewer

教学重点：
- AGV 进入 MuJoCo 后，不再只是二维 GIF，而是一个有 body、joint、geom 和可记录控制目标的模型；
- 本脚本采用“课堂稳定版平面底盘”：x/y/yaw 三个平面关节 + data.ctrl 目标记录；
- 高层 A* 生成 path，中层控制器生成局部目标，低层 data.ctrl 记录局部目标，课堂稳定版用平面运动学更新 qpos，并通过 mj_step 推进场景；
- 输出 GIF 和 CSV，用于证明 pose、target、sensor range、target_found 与画面对齐。

说明：这不是完整差速轮胎接触模型，而是面向课堂的 AGV 平面运动学/物理接口示例。
如果要做真实轮胎动力学，需要进一步建模轮子接触、摩擦、轮速闭环和里程计噪声。
"""
from __future__ import annotations

import argparse
import csv
import math
import time
from heapq import heappop, heappush
from pathlib import Path

import mujoco
import numpy as np
from PIL import Image
from mujoco_viewer_compat import ensure_mjpython_for_macos_viewer

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
OUT = ROOT / "outputs"
XML_PATH = DATA / "mujoco_agv_navigation.xml"

W, H = 16, 10
START = (1, 1)
SEARCH_GOAL = (12, 6)
TARGET = (13, 7)
CELL = 0.32
OBSTACLES = {(5, y) for y in range(1, 8)} | {(9, y) for y in range(2, 9)} | {(x, 4) for x in range(9, 14)}
OBSTACLES -= {(5, 5), (9, 7)}


def grid_to_world(p: tuple[int, int]) -> np.ndarray:
    x, y = p
    return np.array([(x - W / 2) * CELL, (H / 2 - y) * CELL, 0.0], dtype=float)


def neighbors(p):
    x, y = p
    for nx, ny in [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]:
        if 0 <= nx < W and 0 <= ny < H and (nx, ny) not in OBSTACLES:
            yield (nx, ny)


def heuristic(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def astar(start, goal):
    pq = []
    heappush(pq, (0, start))
    came = {start: None}
    cost = {start: 0}
    while pq:
        _, cur = heappop(pq)
        if cur == goal:
            break
        for nb in neighbors(cur):
            nc = cost[cur] + 1
            if nb not in cost or nc < cost[nb]:
                cost[nb] = nc
                heappush(pq, (nc + heuristic(nb, goal), nb))
                came[nb] = cur
    if goal not in came:
        raise RuntimeError("A* failed: goal unreachable")
    path = []
    cur = goal
    while cur is not None:
        path.append(cur)
        cur = came[cur]
    return path[::-1]


def yaw_to_quat(yaw: float) -> np.ndarray:
    return np.array([math.cos(yaw / 2), 0.0, 0.0, math.sin(yaw / 2)], dtype=float)


def build_xml() -> str:
    def box(name, pos, size, rgba):
        return f'<geom name="{name}" type="box" pos="{pos[0]:.3f} {pos[1]:.3f} {pos[2]:.3f}" size="{size[0]:.3f} {size[1]:.3f} {size[2]:.3f}" rgba="{rgba}"/>'

    obstacle_xml = []
    for i, cell in enumerate(sorted(OBSTACLES)):
        p = grid_to_world(cell)
        obstacle_xml.append(box(f"obs_{i}", [p[0], p[1], 0.10], [CELL * 0.45, CELL * 0.45, 0.10], "0.08 0.12 0.20 1"))

    target = grid_to_world(TARGET)
    start = grid_to_world(START)
    # x/y/yaw 三个关节的 qpos 是相对 agv_base 初始 pos 的偏移。
    return f"""
<mujoco model="agv_navigation_teaching">
  <compiler angle="radian" coordinate="local"/>
  <option timestep="0.02" gravity="0 0 -9.81"/>
  <visual>
    <global offwidth="960" offheight="720"/>
    <headlight diffuse="0.6 0.6 0.6" ambient="0.25 0.25 0.25" specular="0.1 0.1 0.1"/>
  </visual>
  <asset>
    <texture name="grid" type="2d" builtin="checker" width="512" height="512" rgb1="0.93 0.96 1" rgb2="0.82 0.88 0.95"/>
    <material name="gridmat" texture="grid" texrepeat="12 8" reflectance="0.12"/>
  </asset>
  <worldbody>
    <light pos="0 0 5" dir="0 0 -1" directional="true"/>
    <camera name="top" pos="0 0 6.2" quat="1 0 0 0" fovy="38"/>
    <geom name="floor" type="plane" size="3.2 2.2 0.02" material="gridmat"/>
    {''.join(obstacle_xml)}
    <geom name="target" type="box" pos="{target[0]:.3f} {target[1]:.3f} 0.065" size="0.075 0.075 0.065" rgba="1.0 0.45 0.05 1"/>
    <body name="sensor_disc" mocap="true" pos="{start[0]:.3f} {start[1]:.3f} 0.012">
      <geom name="sensor_range" type="cylinder" size="{CELL*2:.3f} 0.004" rgba="0.1 0.85 0.25 0.18" contype="0" conaffinity="0"/>
    </body>
    <body name="x_axis" pos="0 0 0.08">
      <inertial pos="0 0 0" mass="0.02" diaginertia="0.0001 0.0001 0.0001"/>
      <joint name="x" type="slide" axis="1 0 0" damping="8"/>
      <body name="y_axis">
        <inertial pos="0 0 0" mass="0.02" diaginertia="0.0001 0.0001 0.0001"/>
        <joint name="y" type="slide" axis="0 1 0" damping="8"/>
        <body name="agv_yaw">
          <inertial pos="0 0 0" mass="0.02" diaginertia="0.0001 0.0001 0.0001"/>
          <joint name="yaw" type="hinge" axis="0 0 1" damping="4"/>
          <body name="agv_base" pos="0 0 0">
            <geom name="chassis" type="box" size="0.16 0.11 0.055" rgba="0.12 0.35 0.95 1"/>
            <geom name="front" type="box" pos="0.13 0 0" size="0.035 0.08 0.04" rgba="0.1 0.8 1 1"/>
            <geom name="left_wheel" type="cylinder" pos="0 0.13 -0.035" euler="1.5708 0 0" size="0.045 0.025" rgba="0.02 0.02 0.02 1"/>
            <geom name="right_wheel" type="cylinder" pos="0 -0.13 -0.035" euler="1.5708 0 0" size="0.045 0.025" rgba="0.02 0.02 0.02 1"/>
          </body>
        </body>
      </body>
    </body>
  </worldbody>
  <actuator>
    <position name="x_target" joint="x" kp="0" ctrlrange="-3 3"/>
    <position name="y_target" joint="y" kp="0" ctrlrange="-2 2"/>
    <position name="yaw_target" joint="yaw" kp="0" ctrlrange="-3.1416 3.1416"/>
  </actuator>
</mujoco>
"""


def save_gif(frames, path: Path):
    imgs = [Image.fromarray(f) for f in frames]
    imgs[0].save(path, save_all=True, append_images=imgs[1:], duration=45, loop=0)


def angle_wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def run(record=False, viewer=False):
    DATA.mkdir(exist_ok=True)
    XML_PATH.write_text(build_xml(), encoding="utf-8")
    model = mujoco.MjModel.from_xml_path(str(XML_PATH))
    data = mujoco.MjData(model)
    renderer = mujoco.Renderer(model, width=960, height=720) if record else None
    frames, rows = [], []

    path_grid = astar(START, SEARCH_GOAL)
    path_world = [grid_to_world(p) for p in path_grid]
    target_world = grid_to_world(TARGET)
    start_world = path_world[0]
    xadr = model.joint("x").qposadr[0]
    yadr = model.joint("y").qposadr[0]
    yawr = model.joint("yaw").qposadr[0]
    base_body = model.body("agv_base").id
    data.qpos[xadr] = start_world[0]
    data.qpos[yadr] = start_world[1]
    data.qpos[yawr] = 0.0
    mujoco.mj_forward(model, data)

    def step_to(target_xy, label, steps=65, viewer_obj=None):
        found = False
        for _ in range(steps):
            pos = data.xpos[base_body].copy()
            dx, dy = target_xy[0] - pos[0], target_xy[1] - pos[1]
            desired_yaw = math.atan2(dy, dx) if abs(dx) + abs(dy) > 1e-6 else data.qpos[yawr]
            # data.ctrl 记录“控制器想去哪里”。为了课堂稳定演示，下面用限速运动学更新 qpos。
            data.ctrl[0] = target_xy[0]
            data.ctrl[1] = target_xy[1]
            data.ctrl[2] = desired_yaw

            desired_offset = np.array([data.ctrl[0], data.ctrl[1]], dtype=float)
            current_offset = np.array([data.qpos[xadr], data.qpos[yadr]], dtype=float)
            delta = desired_offset - current_offset
            dist = float(np.linalg.norm(delta))
            max_step = 0.018
            if dist > max_step:
                delta = delta / dist * max_step
            data.qpos[xadr] += delta[0]
            data.qpos[yadr] += delta[1]
            yaw_err = angle_wrap(desired_yaw - data.qpos[yawr])
            data.qpos[yawr] += float(np.clip(yaw_err, -0.07, 0.07))
            mujoco.mj_forward(model, data)

            if model.nmocap > 0:
                data.mocap_pos[0] = np.array([pos[0], pos[1], 0.012])
                data.mocap_quat[0] = yaw_to_quat(data.qpos[yawr])
            dist_to_target = float(np.linalg.norm(pos[:2] - target_world[:2]))
            found = found or dist_to_target <= CELL * 2.0
            mujoco.mj_step(model, data)
            if renderer is not None and (len(rows) % 2 == 0):
                renderer.update_scene(data, camera="top")
                frames.append(renderer.render())
            rows.append([
                label, float(data.time), float(pos[0]), float(pos[1]), float(angle_wrap(data.qpos[yawr])),
                float(target_xy[0]), float(target_xy[1]), float(data.ctrl[0]), float(data.ctrl[1]), float(data.ctrl[2]),
                dist_to_target, bool(found)
            ])
            if viewer_obj is not None:
                viewer_obj.sync()
                time.sleep(0.015)
        return found

    found_any = False
    if viewer:
        import importlib
        mj_viewer = importlib.import_module("mujoco.viewer")
        with mj_viewer.launch_passive(model, data) as v:
            for i, wp in enumerate(path_world):
                found_any = step_to(wp[:2], f"wp_{i}", viewer_obj=v) or found_any
    else:
        for i, wp in enumerate(path_world):
            found_any = step_to(wp[:2], f"wp_{i}") or found_any

    OUT.mkdir(exist_ok=True)
    csv_path = OUT / "mujoco_agv_navigation_log.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["phase", "time", "agv_x", "agv_y", "agv_yaw", "target_x", "target_y", "ctrl_x", "ctrl_y", "ctrl_yaw", "dist_to_object", "target_found"])
        w.writerows(rows)

    print("MuJoCo AGV navigation search")
    print("xml=", XML_PATH)
    print("path_grid=", path_grid)
    print("target=", TARGET, "found=", found_any)
    print("saved log:", csv_path)
    if record:
        gif_path = OUT / "mujoco_agv_navigation.gif"
        save_gif(frames, gif_path)
        Image.fromarray(frames[len(frames)//2]).save(OUT / "mujoco_agv_navigation_preview.png")
        print("saved gif:", gif_path)
        print("preview: streamlit_robot_sim_lab.py -> MuJoCo AGV")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--record", action="store_true", help="生成 GIF 和 CSV")
    parser.add_argument("--viewer", action="store_true", help="打开 MuJoCo viewer")
    args = parser.parse_args()
    if args.viewer:
        ensure_mjpython_for_macos_viewer(__file__)
    run(record=args.record, viewer=args.viewer)
