"""AGV 导航寻物：A* 路径规划 + 视野扫描 + GIF 可视化。

运行：
  python 07_agv_navigation_search.py
  cd outputs && python -m http.server 8001
  浏览器打开 http://localhost:8001/agv_search.gif

教学重点：
- AGV 不是机械臂，核心是 map、pose、path、sensor range；
- 先规划到搜索区域，再用局部视野发现目标；
- 和 Panda 抓取组合起来，就是“移动到附近 + 机械臂操作”的具身任务链。
"""
from pathlib import Path
from heapq import heappush, heappop
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs'
W, H = 16, 10
START = (1, 1)
TARGET = (13, 7)
SEARCH_GOAL = (12, 6)
OBSTACLES = {(5, y) for y in range(1, 8)} | {(9, y) for y in range(2, 9)} | {(x, 4) for x in range(9, 14)}
OBSTACLES -= {(5, 5), (9, 7)}


def neighbors(p):
    x, y = p
    for nx, ny in [(x+1,y),(x-1,y),(x,y+1),(x,y-1)]:
        if 0 <= nx < W and 0 <= ny < H and (nx, ny) not in OBSTACLES:
            yield (nx, ny)


def heuristic(a, b):
    return abs(a[0]-b[0]) + abs(a[1]-b[1])


def astar(start, goal):
    pq = []
    heappush(pq, (0, start))
    came = {start: None}
    cost = {start: 0}
    while pq:
        _, cur = heappop(pq)
        if cur == goal:
            break
        for nb in neighbors(cur):
            nc = cost[cur] + 1
            if nb not in cost or nc < cost[nb]:
                cost[nb] = nc
                priority = nc + heuristic(nb, goal)
                heappush(pq, (priority, nb))
                came[nb] = cur
    path = []
    cur = goal
    while cur is not None:
        path.append(cur); cur = came[cur]
    return path[::-1]


def draw(path_prefix, agv, found=False):
    cell = 54
    img = Image.new('RGB', (W*cell, H*cell), (238, 242, 247))
    d = ImageDraw.Draw(img)
    for x in range(W):
        for y in range(H):
            box = [x*cell, y*cell, (x+1)*cell, (y+1)*cell]
            fill = (30, 41, 59) if (x, y) in OBSTACLES else (248, 250, 252)
            d.rectangle(box, fill=fill, outline=(203, 213, 225))
    for p in path_prefix:
        x, y = p
        d.rectangle([x*cell+16, y*cell+16, x*cell+38, y*cell+38], fill=(96, 165, 250))
    # sensor range
    ax, ay = agv
    r = 2
    d.ellipse([(ax-r)*cell+cell//2, (ay-r)*cell+cell//2, (ax+r)*cell+cell//2, (ay+r)*cell+cell//2], outline=(34,197,94), width=3)
    # target
    tx, ty = TARGET
    color = (239, 68, 68) if found else (251, 146, 60)
    d.rectangle([tx*cell+14, ty*cell+14, tx*cell+40, ty*cell+40], fill=color)
    # agv
    d.rounded_rectangle([ax*cell+8, ay*cell+10, ax*cell+46, ay*cell+44], radius=8, fill=(37, 99, 235))
    d.text((10, 8), 'AGV navigation search: A* path + local sensor range', fill=(15, 23, 42))
    d.text((10, 30), f'pose={agv}, target_found={found}', fill=(15, 23, 42))
    return img


def main():
    path = astar(START, SEARCH_GOAL)
    frames = []
    found = False
    for i, agv in enumerate(path):
        if heuristic(agv, TARGET) <= 2:
            found = True
        frames.append(draw(path[:i+1], agv, found))
    OUT.mkdir(exist_ok=True)
    gif = OUT / 'agv_search.gif'
    frames[0].save(gif, save_all=True, append_images=frames[1:], duration=320, loop=0)
    print('AGV path=', path)
    print('target=', TARGET, 'found=', found)
    print('saved gif:', gif)


if __name__ == '__main__':
    main()
