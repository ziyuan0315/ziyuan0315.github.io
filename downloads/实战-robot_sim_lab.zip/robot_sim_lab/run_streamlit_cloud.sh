#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
streamlit run streamlit_robot_sim_lab.py \
  --server.port="${PORT:-8501}" \
  --server.address=0.0.0.0 \
  --server.headless=true \
  --server.enableCORS=false \
  --server.enableXsrfProtection=false
