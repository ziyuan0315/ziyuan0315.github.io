"""MuJoCo：Franka Panda 抓方块可视化。

使用 Google DeepMind MuJoCo Menagerie 的 Franka Panda 官方模型。
运行：
  python 03_mujoco_panda_pick_cube.py --viewer
或生成浏览器可看的 GIF：
  python 03_mujoco_panda_pick_cube.py --record
  cd outputs && python -m http.server 8001

教学重点：
- MJCF 定义 body/joint/geom/actuator；
- data.ctrl[:7] 给 7 个关节位置目标；data.ctrl[7] 控制夹爪开合；
- mujoco.mj_step(model, data) 推进物理状态；
- qpos/qvel/body xpos/日志是验证证据。
"""
import argparse
import csv
from pathlib import Path
import numpy as np
import mujoco
from PIL import Image
from mujoco_viewer_compat import ensure_mjpython_for_macos_viewer

ROOT = Path(__file__).resolve().parent
PANDA_DIR = ROOT / 'assets' / 'mujoco_menagerie' / 'franka_emika_panda'
XML = PANDA_DIR / 'mjx_single_cube.xml'
OUT = ROOT / 'outputs'


def interp(a, b, n):
    for i in range(n):
        s = (i + 1) / n
        yield (1 - s) * a + s * b


def save_gif(frames, path):
    imgs = [Image.fromarray(f) for f in frames]
    imgs[0].save(path, save_all=True, append_images=imgs[1:], duration=50, loop=0)


def set_box_pose_near_hand(model, data, offset=(0, 0, -0.13)):
    """课堂稳定抓取：夹爪闭合后，把 free box 的位姿跟随 hand。"""
    body_id = model.body('hand').id
    # mjx_single_cube.xml 的 box freejoint 没有名字，位于最后一个 joint。
    box_joint_id = model.njnt - 1
    adr = model.jnt_qposadr[box_joint_id]
    pos = data.xpos[body_id] + np.array(offset)
    data.qpos[adr:adr+3] = pos
    data.qpos[adr+3:adr+7] = np.array([1, 0, 0, 0])


def run_segment(model, data, ctrl_seq, rows, viewer=None, renderer=None, frames=None, attach_box=False, label=''):
    for ctrl in ctrl_seq:
        data.ctrl[:] = ctrl
        if attach_box:
            set_box_pose_near_hand(model, data)
        mujoco.mj_step(model, data)
        if viewer is not None:
            viewer.sync()
        if renderer is not None and len(rows) % 3 == 0:
            renderer.update_scene(data)
            frames.append(renderer.render())
        hand = data.xpos[model.body('hand').id].copy()
        box = data.xpos[model.body('box').id].copy()
        rows.append([label, float(data.time), *data.qpos[:7], float(data.ctrl[7]), *hand, *box])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--viewer', action='store_true')
    parser.add_argument('--record', action='store_true')
    args = parser.parse_args()
    if args.viewer:
        ensure_mjpython_for_macos_viewer(__file__)

    model = mujoco.MjModel.from_xml_path(str(XML))
    data = mujoco.MjData(model)
    home_id = model.key('home').id
    pickup_id = model.key('pickup').id
    mujoco.mj_resetDataKeyframe(model, data, home_id)

    q_home = model.key_ctrl[home_id].copy()
    q_pick = model.key_ctrl[pickup_id].copy()
    q_close = q_pick.copy(); q_close[7] = 0.0
    q_lift = q_close.copy(); q_lift[1] = 0.12; q_lift[3] = -1.85; q_lift[5] = 2.20
    q_place = q_close.copy(); q_place[0] = -0.35; q_place[1] = 0.30; q_place[3] = -1.75; q_place[5] = 2.05
    q_open = q_place.copy(); q_open[7] = 0.04

    print('MuJoCo Franka Panda pick cube')
    print('model=', XML)
    print('nq/nv/nu=', model.nq, model.nv, model.nu)
    print('keyframes=', [model.key(i).name for i in range(model.nkey)])
    print('ctrl: first 7 = arm joint targets, ctrl[7] = gripper open/close')

    rows, frames = [], []
    renderer = mujoco.Renderer(model, width=640, height=480) if args.record else None

    def scenario(viewer=None):
        run_segment(model, data, interp(q_home, q_pick, 220), rows, viewer, renderer, frames, False, 'approach')
        run_segment(model, data, [q_close]*90, rows, viewer, renderer, frames, False, 'close_gripper')
        run_segment(model, data, interp(q_close, q_lift, 170), rows, viewer, renderer, frames, True, 'lift_with_cube')
        run_segment(model, data, interp(q_lift, q_place, 180), rows, viewer, renderer, frames, True, 'move_to_place')
        run_segment(model, data, [q_open]*80, rows, viewer, renderer, frames, False, 'open_gripper')

    if args.viewer:
        import importlib
        mj_viewer = importlib.import_module('mujoco.viewer')
        with mj_viewer.launch_passive(model, data) as viewer:
            scenario(viewer)
    else:
        scenario(None)

    OUT.mkdir(exist_ok=True)
    csv_path = OUT / 'mujoco_panda_pick_log.csv'
    with csv_path.open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['phase','time','q1','q2','q3','q4','q5','q6','q7','gripper_ctrl','hand_x','hand_y','hand_z','box_x','box_y','box_z'])
        w.writerows(rows)
    print('saved log:', csv_path)
    print('last row:', rows[-1])

    if args.record:
        gif_path = OUT / 'mujoco_panda_pick_cube.gif'
        save_gif(frames, gif_path)
        print('saved gif:', gif_path)
        print('preview: cd outputs && python -m http.server 8001 -> http://localhost:8001/mujoco_panda_pick_cube.gif')


if __name__ == '__main__':
    main()
